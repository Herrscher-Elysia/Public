import pygame, sys
import random
from button import Button


pygame.init()

SCREEN = pygame.display.set_mode((1280, 720)) # 40x32, 40x18
pygame.display.set_caption("Python = You")

BG = pygame.image.load("assets/BG.png")

def get_font(size): # Returns Press-Start-2P in the desired size
    return pygame.font.Font("assets/font.ttf", size)

def play():
    while True:
        PLAY_MOUSE_POS = pygame.mouse.get_pos()

        SCREEN.fill("grey")

        PLAY_LEVEL_1 = Button(image=None, pos=(150,100), text_input="Level 1", font=get_font(30),
                              base_color="White", hovering_color="Green")
        PLAY_LEVEL_2 = Button(image=None, pos=(465,100), text_input="Level 2", font=get_font(30),
                              base_color="White", hovering_color="Green")
        PLAY_LEVEL_3 = Button(image=None, pos=(780,100), text_input="Level 3", font=get_font(30),
                              base_color="White", hovering_color="Green")
        PLAY_LEVEL_4 = Button(image=None, pos=(150,250), text_input="Level 4", font=get_font(30),
                              base_color="White", hovering_color="Green")
        PLAY_LEVEL_5 = Button(image=None, pos=(465,250), text_input="Level 5", font=get_font(30),
                              base_color="White", hovering_color="Green")
        PLAY_LEVEL_6 = Button(image=None, pos=(780,250), text_input="Level 6", font=get_font(30),
                              base_color="White", hovering_color="Green")
        PLAY_LEVEL_7 = Button(image=None, pos=(150,400), text_input="Level 7", font=get_font(30),
                              base_color="White", hovering_color="Green")
        PLAY_LEVEL_8 = Button(image=None, pos=(465,400), text_input="Level 8", font=get_font(30),
                              base_color="White", hovering_color="Green")
        PLAY_LEVEL_9 = Button(image=None, pos=(780,400), text_input="Level 9", font=get_font(30),
                              base_color="White", hovering_color="Green")
        PLAY_LEVEL_10 = Button(image=None, pos=(1095,550), text_input="Level 10", font=get_font(30),
                              base_color="White", hovering_color="Green")


        PLAY_BACK = Button(image=None, pos=(50,700),
                            text_input="BACK", font=get_font(20), base_color="White", hovering_color="Green")

        PLAY_LEVEL_1.changeColor(PLAY_MOUSE_POS)
        PLAY_LEVEL_1.update(SCREEN)
        
        PLAY_LEVEL_2.changeColor(PLAY_MOUSE_POS)
        PLAY_LEVEL_2.update(SCREEN)

        PLAY_LEVEL_3.changeColor(PLAY_MOUSE_POS)
        PLAY_LEVEL_3.update(SCREEN)
        
        PLAY_LEVEL_4.changeColor(PLAY_MOUSE_POS)
        PLAY_LEVEL_4.update(SCREEN)

        PLAY_LEVEL_5.changeColor(PLAY_MOUSE_POS)
        PLAY_LEVEL_5.update(SCREEN)
        
        PLAY_LEVEL_6.changeColor(PLAY_MOUSE_POS)
        PLAY_LEVEL_6.update(SCREEN)

        PLAY_LEVEL_7.changeColor(PLAY_MOUSE_POS)
        PLAY_LEVEL_7.update(SCREEN)
        
        PLAY_LEVEL_8.changeColor(PLAY_MOUSE_POS)
        PLAY_LEVEL_8.update(SCREEN)

        PLAY_LEVEL_9.changeColor(PLAY_MOUSE_POS)
        PLAY_LEVEL_9.update(SCREEN)
        
        PLAY_LEVEL_10.changeColor(PLAY_MOUSE_POS)
        PLAY_LEVEL_10.update(SCREEN)


        
        PLAY_BACK.changeColor(PLAY_MOUSE_POS)
        PLAY_BACK.update(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BACK.checkForInput(PLAY_MOUSE_POS):
                    main_menu()
                elif PLAY_LEVEL_1.checkForInput(PLAY_MOUSE_POS):
                    level_1()
                elif PLAY_LEVEL_2.checkForInput(PLAY_MOUSE_POS):
                    level_2()
                elif PLAY_LEVEL_3.checkForInput(PLAY_MOUSE_POS):
                    level_3()
                elif PLAY_LEVEL_4.checkForInput(PLAY_MOUSE_POS):
                    level_4()
                elif PLAY_LEVEL_5.checkForInput(PLAY_MOUSE_POS):
                    level_5()
                elif PLAY_LEVEL_6.checkForInput(PLAY_MOUSE_POS):
                    level_6()
                elif PLAY_LEVEL_7.checkForInput(PLAY_MOUSE_POS):
                    level_7()
                elif PLAY_LEVEL_8.checkForInput(PLAY_MOUSE_POS):
                    level_8()
                elif PLAY_LEVEL_9.checkForInput(PLAY_MOUSE_POS):
                    level_9()
                elif PLAY_LEVEL_10.checkForInput(PLAY_MOUSE_POS):
                    level_10()


        pygame.display.update()
    
def options():      # global character로 캐릭터 이미지 바꾸는 기능 넣어도 될 듯?
    while True:
        OPTIONS_MOUSE_POS = pygame.mouse.get_pos()

        SCREEN.fill("black")

        OPTIONS_TEXT = get_font(45).render("This is the OPTIONS screen.", True, "Black")
        OPTIONS_RECT = OPTIONS_TEXT.get_rect(center=(640, 260))
        SCREEN.blit(OPTIONS_TEXT, OPTIONS_RECT)

        How_To_Play = Button(image=None, pos=(640,300), text_input="How to Play", font=get_font(30),
                              base_color="White", hovering_color="Green")
        How_To_Play.changeColor(OPTIONS_MOUSE_POS)
        How_To_Play.update(SCREEN)


        OPTIONS_BACK = Button(image=None, pos=(640, 460), 
                            text_input="BACK", font=get_font(45), base_color="White", hovering_color="Green")

        OPTIONS_BACK.changeColor(OPTIONS_MOUSE_POS)
        OPTIONS_BACK.update(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if OPTIONS_BACK.checkForInput(OPTIONS_MOUSE_POS):
                    main_menu()
                if How_To_Play.checkForInput(OPTIONS_MOUSE_POS):
                    howtoplay()
                
        pygame.display.update()

def main_menu():
    while True:
        SCREEN.blit(BG, (0, 0))

        MENU_MOUSE_POS = pygame.mouse.get_pos()

        MENU_TEXT = get_font(80).render("Python Is You", True, "#b68f40")
        MENU_RECT = MENU_TEXT.get_rect(center=(640, 100))

        PLAY_BUTTON = Button(image=pygame.image.load("assets/Play Rect.png"), pos=(640, 250), 
                            text_input="PLAY", font=get_font(75), base_color="#d7fcd4", hovering_color="White")
        OPTIONS_BUTTON = Button(image=pygame.image.load("assets/Options Rect.png"), pos=(640, 400), 
                            text_input="OPTIONS", font=get_font(75), base_color="#d7fcd4", hovering_color="White")
        QUIT_BUTTON = Button(image=pygame.image.load("assets/Quit Rect.png"), pos=(640, 550), 
                            text_input="QUIT", font=get_font(75), base_color="#d7fcd4", hovering_color="White")

        SCREEN.blit(MENU_TEXT, MENU_RECT)

        for button in [PLAY_BUTTON, OPTIONS_BUTTON, QUIT_BUTTON]:
            button.changeColor(MENU_MOUSE_POS)
            button.update(SCREEN)
        
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BUTTON.checkForInput(MENU_MOUSE_POS):
                    play()
                if OPTIONS_BUTTON.checkForInput(MENU_MOUSE_POS):
                    options()
                if QUIT_BUTTON.checkForInput(MENU_MOUSE_POS):
                    pygame.quit()
                    sys.exit()

        pygame.display.update()

def howtoplay():
    while True:
        HOWTOPLAY_MOUSE_POS = pygame.mouse.get_pos()

        SCREEN.fill("black")
        
        MOVE_TEXT = get_font(45).render("WASD to move", True, "White")
        MOVE_RECT = MOVE_TEXT.get_rect(center=(640, 300))
        SCREEN.blit(MOVE_TEXT, MOVE_RECT)

        RESTART_TEXT = get_font(45).render("R to restart", True, "White")
        RESTART_RECT = RESTART_TEXT.get_rect(center=(640,420))
        SCREEN.blit(RESTART_TEXT, RESTART_RECT)

        HOWTOPLAY_BACK = Button(image=None, pos=(640, 540), text_input="BACK", font=get_font(45),
                                base_color="White", hovering_color="Green")

        HOWTOPLAY_BACK.changeColor(HOWTOPLAY_MOUSE_POS)
        HOWTOPLAY_BACK.update(SCREEN)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if HOWTOPLAY_BACK.checkForInput(HOWTOPLAY_MOUSE_POS):
                    options()

        pygame.display.update()





# LEVEL1


def level_1():

    PC = pygame.image.load("assets/Python Character.png") # 캐릭터들 불러옴
    PC = pygame.transform.scale(PC, (40, 40))

    FC = pygame.image.load("assets/Flag Character.png")
    FC = pygame.transform.scale(FC, (40, 40))

    
    LEVEL_1_CLEAR = False

    
    PC_x_pos = 160
    PC_y_pos = 320
    
    FC_x_pos = 1000
    FC_y_pos = 600


    PAUSE = False
    
    
    while True:

        # 버튼 정의

        LEVEL_1_MOUSE_POS = pygame.mouse.get_pos()
        
        SCREEN.blit(BG, (0, 0))

        SCREEN.blit(PC, (PC_x_pos, PC_y_pos))
        SCREEN.blit(FC, (FC_x_pos, FC_y_pos))

        LEVEL1_TEXT1 = get_font(20).render("Python = You", True, "White")
        LEVEL1_RECT1 = LEVEL1_TEXT1.get_rect(center=(160, 20))
        SCREEN.blit(LEVEL1_TEXT1, LEVEL1_RECT1)

        LEVEL1_TEXT2 = get_font(20).render("Flag = Win", True, "White")
        LEVEL1_RECT2 = LEVEL1_TEXT2.get_rect(center=(140, 40))
        SCREEN.blit(LEVEL1_TEXT2, LEVEL1_RECT2)    



        if PC_x_pos == FC_x_pos and PC_y_pos == FC_y_pos: #클리어 조건
            LEVEL_1_CLEAR = True

        while LEVEL_1_CLEAR == True:
            CLEAR_MOUSE_POS = pygame.mouse.get_pos()
            
            SCREEN.blit(BG, (0, 0))
            LEVEL_1_CLEAR_TEXT = get_font(45).render("Level 1 clear", True, "White")
            LEVEL_1_CLEAR_RECT = LEVEL_1_CLEAR_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(LEVEL_1_CLEAR_TEXT, LEVEL_1_CLEAR_RECT)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                            base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            LEVEL2 = Button(image=None, pos=(640,420), text_input="next level", font=get_font(30),
                            base_color="White", hovering_color="Green")
            LEVEL2.changeColor(CLEAR_MOUSE_POS)
            LEVEL2.update(SCREEN)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if LEVEL2.checkForInput(CLEAR_MOUSE_POS):
                        level_2()

                        
            pygame.display.update()
        
        
# 파이썬 캐릭터 움직임
            
        for event in pygame.event.get():
                
            if event.type == pygame.KEYUP:
                    
                if event.key == pygame.K_a and PC_x_pos>0:
                    PC_x_pos -= 40
                        
                if event.key == pygame.K_d and PC_x_pos<1240:
                    PC_x_pos += 40
                        
                if event.key == pygame.K_w and PC_y_pos>0:
                    PC_y_pos -= 40
                        
                if event.key == pygame.K_s and PC_y_pos<680:
                    PC_y_pos += 40        

                if event.key == pygame.K_r:
                    level_1()

                if event.key == pygame.K_ESCAPE:
                    PAUSE = True

            while PAUSE == True:
                PAUSE_MOUSE_POS = pygame.mouse.get_pos()
                
                SCREEN.blit(BG, (0, 0))
                PAUSE_TEXT = get_font(45).render("paused", True, "White")
                PAUSE_RECT = PAUSE_TEXT.get_rect(center=(640, 200))
                SCREEN.blit(PAUSE_TEXT, PAUSE_RECT)
                BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOMENU.changeColor(PAUSE_MOUSE_POS)
                BACKTOMENU.update(SCREEN)
                BACKTOGAME = Button(image=None, pos=(640,420), text_input="back to game", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOGAME.changeColor(PAUSE_MOUSE_POS)
                BACKTOGAME.update(SCREEN)

                pygame.display.update()

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if BACKTOMENU.checkForInput(PAUSE_MOUSE_POS):
                            play()
                        if BACKTOGAME.checkForInput(PAUSE_MOUSE_POS):
                            PAUSE = False
                    

                        
            pygame.display.update()
                
        pygame.display.update()




# LEVEL2

def level_2():

    PC = pygame.image.load("assets/Python Character.png") # 캐릭터들 불러옴
    PC = pygame.transform.scale(PC, (40, 40))

    FC = pygame.image.load("assets/Flag Character.png")
    FC = pygame.transform.scale(FC, (40, 40))

    BH = pygame.image.load("assets/Blackhole.png")
    BH = pygame.transform.scale(BH, (40, 40))

    WH = pygame.image.load("assets/Whitehole.png")
    WH = pygame.transform.scale(WH, (40, 40))

    WALL = pygame.image.load("assets/W40x720.png")



    
    LEVEL_2_CLEAR = False

    
    PC_x_pos = 160
    PC_y_pos = 520
    
    FC_x_pos = 760
    FC_y_pos = 200

    BH_x_pos = 200
    BH_y_pos = 160

    WH_x_pos = 1040
    WH_y_pos = 600

    WALL_x_pos = 600
    WALL_y_pos = 0


    PAUSE = False
    
    
    while True:

        # 버튼 정의

        LEVEL_2_MOUSE_POS = pygame.mouse.get_pos()
        
        SCREEN.blit(BG, (0, 0))

        SCREEN.blit(PC, (PC_x_pos, PC_y_pos))
        SCREEN.blit(FC, (FC_x_pos, FC_y_pos))
        SCREEN.blit(BH, (BH_x_pos, BH_y_pos))
        SCREEN.blit(WH, (WH_x_pos, WH_y_pos))
        SCREEN.blit(WALL, (WALL_x_pos, WALL_y_pos))

        LEVEL2_TEXT1 = get_font(20).render("Python = You", True, "White")
        LEVEL2_RECT1 = LEVEL2_TEXT1.get_rect(center=(160, 20))
        SCREEN.blit(LEVEL2_TEXT1, LEVEL2_RECT1)

        LEVEL2_TEXT2 = get_font(20).render("Flag = Win", True, "White")
        LEVEL2_RECT2 = LEVEL2_TEXT2.get_rect(center=(140, 40))
        SCREEN.blit(LEVEL2_TEXT2, LEVEL2_RECT2)

        LEVEL2_TEXT3 = get_font(20).render("Wall = Stop", True, "White")
        LEVEL2_RECT3 = LEVEL2_TEXT3.get_rect(center=(150, 60))
        SCREEN.blit(LEVEL2_TEXT3, LEVEL2_RECT3) 

        LEVEL2_TEXT4 = get_font(20).render("Blackhole = Teleport", True, "White")
        LEVEL2_RECT4 = LEVEL2_TEXT4.get_rect(center=(240, 80))
        SCREEN.blit(LEVEL2_TEXT4, LEVEL2_RECT4) 
        


        if PC_x_pos == FC_x_pos and PC_y_pos == FC_y_pos: #클리어 조건
            LEVEL_2_CLEAR = True

        if PC_x_pos == BH_x_pos and PC_y_pos == BH_y_pos:
            PC_x_pos = WH_x_pos
            PC_y_pos = WH_y_pos


        while LEVEL_2_CLEAR == True:
            CLEAR_MOUSE_POS = pygame.mouse.get_pos()
            
            SCREEN.blit(BG, (0, 0))
            LEVEL_2_CLEAR_TEXT = get_font(45).render("Level 2 clear", True, "White")
            LEVEL_2_CLEAR_RECT = LEVEL_2_CLEAR_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(LEVEL_2_CLEAR_TEXT, LEVEL_2_CLEAR_RECT)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                            base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            LEVEL3 = Button(image=None, pos=(640,420), text_input="next level", font=get_font(30),
                            base_color="White", hovering_color="Green")
            LEVEL3.changeColor(CLEAR_MOUSE_POS)
            LEVEL3.update(SCREEN)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if LEVEL3.checkForInput(CLEAR_MOUSE_POS):
                        level_3()

                        
            pygame.display.update()
        
        
# 파이썬 캐릭터 움직임
            
        for event in pygame.event.get():
                
            if event.type == pygame.KEYUP:
                    
                if event.key == pygame.K_a and PC_x_pos>0:
                    PC_x_pos -= 40
                    if PC_x_pos == WALL_x_pos:
                        PC_x_pos += 40
                        
                if event.key == pygame.K_d and PC_x_pos<1240:
                    PC_x_pos += 40
                    if PC_x_pos == WALL_x_pos:
                        PC_x_pos -= 40
                        
                if event.key == pygame.K_w and PC_y_pos>0:
                    PC_y_pos -= 40
                        
                if event.key == pygame.K_s and PC_y_pos<680:
                    PC_y_pos += 40        

                if event.key == pygame.K_r:
                    level_1()

                if event.key == pygame.K_ESCAPE:
                    PAUSE = True

            while PAUSE == True:
                PAUSE_MOUSE_POS = pygame.mouse.get_pos()
                
                SCREEN.blit(BG, (0, 0))
                PAUSE_TEXT = get_font(45).render("paused", True, "White")
                PAUSE_RECT = PAUSE_TEXT.get_rect(center=(640, 200))
                SCREEN.blit(PAUSE_TEXT, PAUSE_RECT)
                BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOMENU.changeColor(PAUSE_MOUSE_POS)
                BACKTOMENU.update(SCREEN)
                BACKTOGAME = Button(image=None, pos=(640,420), text_input="back to game", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOGAME.changeColor(PAUSE_MOUSE_POS)
                BACKTOGAME.update(SCREEN)

                pygame.display.update()

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if BACKTOMENU.checkForInput(PAUSE_MOUSE_POS):
                            play()
                        if BACKTOGAME.checkForInput(PAUSE_MOUSE_POS):
                            PAUSE = False
                    

                        
            pygame.display.update()
                
        pygame.display.update()



# LEVEL3

def level_3():

    PC = pygame.image.load("assets/Python Character.png") # 캐릭터들 불러옴
    PC = pygame.transform.scale(PC, (40, 40))

    FC = pygame.image.load("assets/Flag Character.png")
    FC = pygame.transform.scale(FC, (40, 40))

    KEY = pygame.image.load("assets/KEY.png")
    KEY = pygame.transform.scale(KEY, (40, 40))
    
    LEVEL_3_CLEAR = False

    
    PC_x_pos = 600
    PC_y_pos = 320
    
    FC_x_pos = 520
    FC_y_pos = 280

    KEY_x_pos = 80
    KEY_y_pos = 680


    PAUSE = False

    Key = 'False'
    HAVEKEY = False
    
    
    while True:

        # 버튼 정의

        LEVEL_3_MOUSE_POS = pygame.mouse.get_pos()
        
        SCREEN.blit(BG, (0, 0))

        SCREEN.blit(PC, (PC_x_pos, PC_y_pos))
        SCREEN.blit(FC, (FC_x_pos, FC_y_pos))
        if HAVEKEY == False:
            SCREEN.blit(KEY, (KEY_x_pos, KEY_y_pos))

        LEVEL3_TEXT1 = get_font(20).render("Python = You", True, "White")
        LEVEL3_RECT1 = LEVEL3_TEXT1.get_rect(center=(160, 20))
        SCREEN.blit(LEVEL3_TEXT1, LEVEL3_RECT1)

        LEVEL3_TEXT2 = get_font(20).render("if You have Key == True:", True, "White")
        LEVEL3_RECT2 = LEVEL3_TEXT2.get_rect(center=(260, 50))
        SCREEN.blit(LEVEL3_TEXT2, LEVEL3_RECT2)

        LEVEL3_TEXT3 = get_font(20).render("Flag = Win", True, "White")
        LEVEL3_RECT3 = LEVEL3_TEXT3.get_rect(center=(150, 70))
        SCREEN.blit(LEVEL3_TEXT3, LEVEL3_RECT3) 

        LEVEL3_TEXT4 = get_font(20).render("You have Key = %s"%Key, True, "White")
        LEVEL3_RECT4 = LEVEL3_TEXT4.get_rect(center=(220, 100))
        SCREEN.blit(LEVEL3_TEXT4, LEVEL3_RECT4)
        


        if PC_x_pos == FC_x_pos and PC_y_pos == FC_y_pos and HAVEKEY == True: #클리어 조건
            LEVEL_3_CLEAR = True

        if PC_x_pos == KEY_x_pos and PC_y_pos == KEY_y_pos:
            Key = 'True'
            HAVEKEY = True



        while LEVEL_3_CLEAR == True:
            CLEAR_MOUSE_POS = pygame.mouse.get_pos()
            
            SCREEN.blit(BG, (0, 0))
            LEVEL_3_CLEAR_TEXT = get_font(45).render("Level 3 clear", True, "White")
            LEVEL_3_CLEAR_RECT = LEVEL_3_CLEAR_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(LEVEL_3_CLEAR_TEXT, LEVEL_3_CLEAR_RECT)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                            base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            LEVEL3 = Button(image=None, pos=(640,420), text_input="next level", font=get_font(30),
                            base_color="White", hovering_color="Green")
            LEVEL3.changeColor(CLEAR_MOUSE_POS)
            LEVEL3.update(SCREEN)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if LEVEL3.checkForInput(CLEAR_MOUSE_POS):
                        level_4()

                        
            pygame.display.update()
        
        
# 파이썬 캐릭터 움직임
            
        for event in pygame.event.get():
                
            if event.type == pygame.KEYUP:
                    
                if event.key == pygame.K_a and PC_x_pos>0:
                    PC_x_pos -= 40
                        
                if event.key == pygame.K_d and PC_x_pos<1240:
                    PC_x_pos += 40
                        
                if event.key == pygame.K_w and PC_y_pos>0:
                    PC_y_pos -= 40
                        
                if event.key == pygame.K_s and PC_y_pos<680:
                    PC_y_pos += 40        

                if event.key == pygame.K_r:
                    level_3()

                if event.key == pygame.K_ESCAPE:
                    PAUSE = True

            while PAUSE == True:
                PAUSE_MOUSE_POS = pygame.mouse.get_pos()
                
                SCREEN.blit(BG, (0, 0))
                PAUSE_TEXT = get_font(45).render("paused", True, "White")
                PAUSE_RECT = PAUSE_TEXT.get_rect(center=(640, 200))
                SCREEN.blit(PAUSE_TEXT, PAUSE_RECT)
                BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOMENU.changeColor(PAUSE_MOUSE_POS)
                BACKTOMENU.update(SCREEN)
                BACKTOGAME = Button(image=None, pos=(640,420), text_input="back to game", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOGAME.changeColor(PAUSE_MOUSE_POS)
                BACKTOGAME.update(SCREEN)

                pygame.display.update()

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if BACKTOMENU.checkForInput(PAUSE_MOUSE_POS):
                            play()
                        if BACKTOGAME.checkForInput(PAUSE_MOUSE_POS):
                            PAUSE = False
                    

                        
            pygame.display.update()
                
        pygame.display.update()



# LEVEL4

def level_4():

    PC = pygame.image.load("assets/Python Character.png") # 캐릭터들 불러옴
    PC = pygame.transform.scale(PC, (40, 40))

    FC = pygame.image.load("assets/Flag Character.png")
    FC = pygame.transform.scale(FC, (40, 40))

    WALL = pygame.image.load("assets/W480x40.png")
    WALL = pygame.transform.scale(WALL, (720, 40))
    WALL2 = pygame.image.load("assets/W480x40.png")
    WALL2 = pygame.transform.scale(WALL, (720, 40))

    ROCK = pygame.image.load("assets/Rock Character.jpg")
    ROCK = pygame.transform.scale(ROCK, (80, 80))
    ROCK2 = pygame.image.load("assets/Rock Character.jpg")
    ROCK2 = pygame.transform.scale(ROCK, (80, 80))
    
    LEVEL_4_CLEAR = False

    
    PC_x_pos = 360
    PC_y_pos = 360
    
    FC_x_pos = 840
    FC_y_pos = 320

    WALL_x_pos = 280
    WALL_y_pos = 200

    WALL2_x_pos = 280
    WALL2_y_pos = 480

    ROCK_x_pos = 600
    ROCK_y_pos = 400
    ROCK2_x_pos = 680
    ROCK2_y_pos = 240

    PAUSE = False

    while True:

        LEVEL_4_MOUSE_POS = pygame.mouse.get_pos()
        CLEAR_MOUSE_POS = pygame.mouse.get_pos()
        
        SCREEN.blit(BG, (0, 0))

        SCREEN.blit(PC, (PC_x_pos, PC_y_pos))
        SCREEN.blit(FC, (FC_x_pos, FC_y_pos))
        SCREEN.blit(WALL, (WALL_x_pos, WALL_y_pos))
        SCREEN.blit(WALL2, (WALL2_x_pos, WALL2_y_pos))
        SCREEN.blit(ROCK, (ROCK_x_pos, ROCK_y_pos))
        SCREEN.blit(ROCK2, (ROCK2_x_pos, ROCK2_y_pos))

        LEVEL4_TEXT1 = get_font(20).render("Python = You", True, "White")
        LEVEL4_RECT1 = LEVEL4_TEXT1.get_rect(center=(160, 20))
        SCREEN.blit(LEVEL4_TEXT1, LEVEL4_RECT1)

        LEVEL4_TEXT2 = get_font(20).render("Flag = Win", True, "White")
        LEVEL4_RECT2 = LEVEL4_TEXT2.get_rect(center=(140, 40))
        SCREEN.blit(LEVEL4_TEXT2, LEVEL4_RECT2)

        LEVEL4_TEXT3 = get_font(20).render("Wall = Stop", True, "White")
        LEVEL4_RECT3 = LEVEL4_TEXT3.get_rect(center=(150, 60))
        SCREEN.blit(LEVEL4_TEXT3, LEVEL4_RECT3)
        
        LEVEL4_TEXT4 = get_font(20).render("Rock = Defeat", True, "White")
        LEVEL4_RECT4 = LEVEL4_TEXT4.get_rect(center=(170, 80))
        SCREEN.blit(LEVEL4_TEXT4, LEVEL4_RECT4)

        if PC_x_pos == FC_x_pos and PC_y_pos == FC_y_pos: #클리어 조건
            LEVEL_4_CLEAR = True
        if (PC_x_pos in [600, 640] and PC_y_pos in [400, 440]) \
           or (PC_x_pos in [680, 620] and PC_y_pos in [240, 280]):
            SCREEN.blit(BG, (0, 0))
            GAME_OVER_TEXT = get_font(45).render("GAME OVER", True, "White")
            GAME_OVER_RECT = GAME_OVER_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(GAME_OVER_TEXT, GAME_OVER_RECT)
            RESTART = Button(image=None, pos=(640,420), text_input="Restart", font=get_font(30), \
                             base_color="White", hovering_color="Green")
            RESTART.changeColor(CLEAR_MOUSE_POS)
            RESTART.update(SCREEN)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30), \
                                base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if RESTART.checkForInput(CLEAR_MOUSE_POS):
                        level_4()
        

        while LEVEL_4_CLEAR == True:
            CLEAR_MOUSE_POS = pygame.mouse.get_pos()
            
            SCREEN.blit(BG, (0, 0))
            LEVEL_4_CLEAR_TEXT = get_font(45).render("Level 4 clear", True, "White")
            LEVEL_4_CLEAR_RECT = LEVEL_4_CLEAR_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(LEVEL_4_CLEAR_TEXT, LEVEL_4_CLEAR_RECT)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                            base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            LEVEL5 = Button(image=None, pos=(640,420), text_input="next level", font=get_font(30),
                            base_color="White", hovering_color="Green")
            LEVEL5.changeColor(CLEAR_MOUSE_POS)
            LEVEL5.update(SCREEN)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if LEVEL5.checkForInput(CLEAR_MOUSE_POS):
                        level_5()



                        
            pygame.display.update()

# 파이썬 캐릭터 움직임
            
        for event in pygame.event.get():
                
            if event.type == pygame.KEYUP:
                    
                if event.key == pygame.K_a and PC_x_pos>0:
                    PC_x_pos -= 40
                    if PC_x_pos == 960 and PC_y_pos in [200, 480]:
                        PC_x_pos += 40                      
                
                if event.key == pygame.K_d and PC_x_pos<1240:
                    PC_x_pos += 40
                    if PC_x_pos == 280 and PC_y_pos in [200, 480]:
                        PC_x_pos -= 40   
                        
                        
                if event.key == pygame.K_w and PC_y_pos>0:
                    PC_y_pos -= 40
                    if PC_y_pos == 200 and PC_x_pos in range(280,1000,40):
                        PC_y_pos += 40
                        
                if event.key == pygame.K_s and PC_y_pos<680:
                    PC_y_pos += 40
                    if PC_y_pos == 480 and PC_x_pos in range(280,1000,40):
                        PC_y_pos -= 40

                if event.key == pygame.K_r:
                    level_4()

                if event.key == pygame.K_ESCAPE:
                    PAUSE = True

            while PAUSE == True:
                PAUSE_MOUSE_POS = pygame.mouse.get_pos()
                
                SCREEN.blit(BG, (0, 0))
                PAUSE_TEXT = get_font(45).render("paused", True, "White")
                PAUSE_RECT = PAUSE_TEXT.get_rect(center=(640, 200))
                SCREEN.blit(PAUSE_TEXT, PAUSE_RECT)
                BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOMENU.changeColor(PAUSE_MOUSE_POS)
                BACKTOMENU.update(SCREEN)
                BACKTOGAME = Button(image=None, pos=(640,420), text_input="back to game", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOGAME.changeColor(PAUSE_MOUSE_POS)
                BACKTOGAME.update(SCREEN)

                pygame.display.update()

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if BACKTOMENU.checkForInput(PAUSE_MOUSE_POS):
                            play()
                        if BACKTOGAME.checkForInput(PAUSE_MOUSE_POS):
                            PAUSE = False
                    

                        
            pygame.display.update()
                
        pygame.display.update()






# Lv.5

def level_5():

    PC = pygame.image.load("assets/Python Character.png") # 캐릭터들 불러옴
    PC = pygame.transform.scale(PC, (40, 40))

    FC = pygame.image.load("assets/Flag Character.png")
    FC = pygame.transform.scale(FC, (40, 40))

    KEY = pygame.image.load("assets/KEY.png")
    KEY = pygame.transform.scale(KEY, (40, 40))

    Fire = pygame.image.load("assets/Fire.png")

    Water = pygame.image.load("assets/Water.png")
    
    LEVEL_5_CLEAR = False

    
    PC_x_pos = 1240
    PC_y_pos = 80
    
    FC_x_pos = 120
    FC_y_pos = 640

    Fire_x_pos = 760
    Fire_y_pos = 360


    PAUSE = False

    Key = 'False'
    HAVEKEY = True

    ALIVE = True
    
    
    while True:

        # 버튼 정의

        LEVEL_5_MOUSE_POS = pygame.mouse.get_pos()
        CLEAR_MOUSE_POS = pygame.mouse.get_pos()
        
        SCREEN.blit(BG, (0, 0))

        if ALIVE == True:
            SCREEN.blit(PC, (PC_x_pos, PC_y_pos))
        SCREEN.blit(FC, (FC_x_pos, FC_y_pos))
        SCREEN.blit(Fire, (Fire_x_pos, Fire_y_pos))

        LEVEL5_TEXT1 = get_font(20).render("Python = You", True, "White")
        LEVEL5_RECT1 = LEVEL5_TEXT1.get_rect(center=(160, 20))
        SCREEN.blit(LEVEL5_TEXT1, LEVEL5_RECT1)

        LEVEL5_TEXT2 = get_font(20).render("Fire = Death", True, "White")
        LEVEL5_RECT2 = LEVEL5_TEXT2.get_rect(center=(160, 50))
        SCREEN.blit(LEVEL5_TEXT2, LEVEL5_RECT2)

        LEVEL5_TEXT3 = get_font(20).render("Flag = Win", True, "White")
        LEVEL5_RECT3 = LEVEL5_TEXT3.get_rect(center=(140, 80))
        SCREEN.blit(LEVEL5_TEXT3, LEVEL5_RECT3) 

        PC_x_center = PC_x_pos + 20
        PC_y_center = PC_y_pos + 20
        Fire_x_center = Fire_x_pos + 20
        Fire_y_center = Fire_y_pos + 20


        if PC_x_pos == FC_x_pos and PC_y_pos == FC_y_pos and ALIVE == True: #클리어 조건
            LEVEL_5_CLEAR = True

        if (-17<Fire_x_center-PC_x_center<17 and -17<Fire_y_center-PC_y_center<17):
            ALIVE = False
        if ALIVE == False:
            SCREEN.blit(BG, (0, 0))
            GAME_OVER_TEXT = get_font(45).render("GAME OVER", True, "White")
            GAME_OVER_RECT = GAME_OVER_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(GAME_OVER_TEXT, GAME_OVER_RECT)
            RESTART = Button(image=None, pos=(640,420), text_input="Restart", font=get_font(30), \
                             base_color="White", hovering_color="Green")
            RESTART.changeColor(CLEAR_MOUSE_POS)
            RESTART.update(SCREEN)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30), \
                                base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if RESTART.checkForInput(CLEAR_MOUSE_POS):
                        level_5()

        if Fire_x_center<PC_x_center:
            Fire_x_pos += 5
        if Fire_x_center>PC_x_center:
            Fire_x_pos -= 5
        if Fire_y_center<PC_y_center:
            Fire_y_pos += 5
        if Fire_y_center>PC_y_center:
            Fire_y_pos -= 5

        while LEVEL_5_CLEAR == True:
            CLEAR_MOUSE_POS = pygame.mouse.get_pos()
            
            SCREEN.blit(BG, (0, 0))
            LEVEL_5_CLEAR_TEXT = get_font(45).render("Level 5 clear", True, "White")
            LEVEL_5_CLEAR_RECT = LEVEL_5_CLEAR_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(LEVEL_5_CLEAR_TEXT, LEVEL_5_CLEAR_RECT)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                            base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            LEVEL6 = Button(image=None, pos=(640,420), text_input="next level", font=get_font(30),
                            base_color="White", hovering_color="Green")
            LEVEL6.changeColor(CLEAR_MOUSE_POS)
            LEVEL6.update(SCREEN)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if LEVEL6.checkForInput(CLEAR_MOUSE_POS):
                        level_6()

                        
            pygame.display.update()

        
        
        
# 파이썬 캐릭터 움직임
            
        for event in pygame.event.get():
                
            if event.type == pygame.KEYUP:
                    
                if event.key == pygame.K_a and PC_x_pos>0  and ALIVE == True:
                    PC_x_pos -= 40
                        
                if event.key == pygame.K_d and PC_x_pos<1240  and ALIVE == True:
                    PC_x_pos += 40
                        
                if event.key == pygame.K_w and PC_y_pos>0  and ALIVE == True:
                    PC_y_pos -= 40
                        
                if event.key == pygame.K_s and PC_y_pos<680  and ALIVE == True:
                    PC_y_pos += 40        

                if event.key == pygame.K_r:
                    level_5()

                if event.key == pygame.K_ESCAPE:
                    PAUSE = True

            while PAUSE == True:
                PAUSE_MOUSE_POS = pygame.mouse.get_pos()
                
                SCREEN.blit(BG, (0, 0))
                PAUSE_TEXT = get_font(45).render("paused", True, "White")
                PAUSE_RECT = PAUSE_TEXT.get_rect(center=(640, 200))
                SCREEN.blit(PAUSE_TEXT, PAUSE_RECT)
                BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOMENU.changeColor(PAUSE_MOUSE_POS)
                BACKTOMENU.update(SCREEN)
                BACKTOGAME = Button(image=None, pos=(640,420), text_input="back to game", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOGAME.changeColor(PAUSE_MOUSE_POS)
                BACKTOGAME.update(SCREEN)

                pygame.display.update()

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if BACKTOMENU.checkForInput(PAUSE_MOUSE_POS):
                            play()
                        if BACKTOGAME.checkForInput(PAUSE_MOUSE_POS):
                            PAUSE = False
                    

                        
            pygame.display.update()
                
        pygame.display.update()




# Lv.6


def level_6():

    PC = pygame.image.load("assets/Python Character.png") # 캐릭터들 불러옴
    PC = pygame.transform.scale(PC, (40, 40))

    FC = pygame.image.load("assets/Flag Character.png")
    FC = pygame.transform.scale(FC, (40, 40))

    KEY = pygame.image.load("assets/KEY.png")
    KEY = pygame.transform.scale(KEY, (40, 40))

    BH = pygame.image.load("assets/Blackhole.png")
    BH = pygame.transform.scale(BH, (40, 40))

    WH = pygame.image.load("assets/Whitehole.png")
    WH = pygame.transform.scale(WH, (40, 40))

    Fire = pygame.image.load("assets/Fire.png")
    F2 = pygame.image.load("assets/Fire.png")

    W1 = pygame.image.load("assets/W40x720.png")
    W2 = pygame.image.load("assets/W40x720.png")
    W3 = pygame.image.load("assets/W40x720.png")
    W4 = pygame.image.load("assets/W40x720.png")
    W5 = pygame.image.load("assets/W120x40.png")
    W6 = pygame.image.load("assets/W40x720.png")

    
    LEVEL_6_CLEAR = False

    
    PC_x_pos = 1240
    PC_y_pos = 160
    
    FC_x_pos = 40
    FC_y_pos = 480

    Fire_x_pos = 1240
    Fire_y_pos = 0

    F2_x_pos = 1040
    F2_y_pos = 240

    BH_x_pos = 800
    BH_y_pos = 80

    KEY_x_pos = 840
    KEY_y_pos = 600

    WH_x_pos = 200
    WH_y_pos = 280

    W1_x_pos = 1200
    W1_y_pos = -40

    W2_x_pos = 1120
    W2_y_pos = 40

    W3_x_pos = 960
    W3_y_pos = 40

    W4_x_pos = 880
    W4_y_pos = -40

    W5_x_pos = 1000
    W5_y_pos = 40

    W6_x_pos = 560
    W6_y_pos = 0


    PAUSE = False

    Key = 'False'
    HAVEKEY = True

    ALIVE = True
    
    
    while True:

        # 버튼 정의

        LEVEL_6_MOUSE_POS = pygame.mouse.get_pos()
        CLEAR_MOUSE_POS = pygame.mouse.get_pos()
        
        SCREEN.blit(BG, (0, 0))

        if ALIVE == True:
            SCREEN.blit(PC, (PC_x_pos, PC_y_pos))
        SCREEN.blit(FC, (FC_x_pos, FC_y_pos))

        SCREEN.blit(W1, (W1_x_pos, W1_y_pos))
        SCREEN.blit(W2, (W2_x_pos, W2_y_pos))
        SCREEN.blit(W3, (W3_x_pos, W3_y_pos))
        SCREEN.blit(W4, (W4_x_pos, W4_y_pos))
        SCREEN.blit(W5, (W5_x_pos, W5_y_pos))
        SCREEN.blit(W6, (W6_x_pos, W6_y_pos))
        SCREEN.blit(BH, (BH_x_pos, BH_y_pos))
        SCREEN.blit(WH, (WH_x_pos, WH_y_pos))
        if HAVEKEY == False:
            SCREEN.blit(KEY, (KEY_x_pos, KEY_y_pos))

        SCREEN.blit(Fire, (Fire_x_pos, Fire_y_pos))
        SCREEN.blit(F2, (F2_x_pos, F2_y_pos))


        LEVEL6_TEXT1 = get_font(20).render("Python = You", True, "White")
        LEVEL6_RECT1 = LEVEL6_TEXT1.get_rect(center=(160, 20))
        SCREEN.blit(LEVEL6_TEXT1, LEVEL6_RECT1)
        
        LEVEL6_TEXT2 = get_font(20).render("Blackhole = Teleport", True, "White")
        LEVEL6_RECT2 = LEVEL6_TEXT2.get_rect(center=(240, 50))
        SCREEN.blit(LEVEL6_TEXT2, LEVEL6_RECT2)

        LEVEL6_TEXT3 = get_font(20).render("Flag = Win", True, "White")
        LEVEL6_RECT3 = LEVEL6_TEXT3.get_rect(center=(140, 80))
        SCREEN.blit(LEVEL6_TEXT3, LEVEL6_RECT3) 

        LEVEL6_TEXT5 = get_font(20).render("Fire = Death", True, "White")
        LEVEL6_RECT5 = LEVEL6_TEXT5.get_rect(center=(160, 110))
        SCREEN.blit(LEVEL6_TEXT5, LEVEL6_RECT5)
        
        LEVEL6_TEXT6 = get_font(20).render("Wall = Stop", True, "White")
        LEVEL6_RECT6 = LEVEL6_TEXT3.get_rect(center=(140, 140))
        SCREEN.blit(LEVEL6_TEXT6, LEVEL6_RECT6)

        
        PC_x_center = PC_x_pos + 20
        PC_y_center = PC_y_pos + 20
        Fire_x_center = Fire_x_pos + 20
        Fire_y_center = Fire_y_pos + 20

        if BH_x_pos == 640:
            BH_y_pos -= 10
            

        if BH_x_pos == 800:
            BH_y_pos += 10

        if BH_y_pos == 40:
            BH_x_pos += 10

        if BH_y_pos == 640:
            BH_x_pos -= 10
            

        if PC_x_pos == FC_x_pos and PC_y_pos == FC_y_pos and HAVEKEY == True and ALIVE == True: #클리어 조건
            LEVEL_6_CLEAR = True

        if PC_x_pos == KEY_x_pos and PC_y_pos == KEY_y_pos:
            Key = 'True'
            HAVEKEY = True


        if PC_x_pos == BH_x_pos and PC_y_pos == BH_y_pos:
            PC_x_pos = WH_x_pos
            PC_y_pos = WH_y_pos

        if (-17<Fire_x_center-PC_x_center<17 and -17<Fire_y_center-PC_y_center<17):
            ALIVE = False
        if ALIVE == False:
            SCREEN.blit(BG, (0, 0))
            GAME_OVER_TEXT = get_font(45).render("GAME OVER", True, "White")
            GAME_OVER_RECT = GAME_OVER_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(GAME_OVER_TEXT, GAME_OVER_RECT)
            RESTART = Button(image=None, pos=(640,420), text_input="Restart", font=get_font(30), \
                             base_color="White", hovering_color="Green")
            RESTART.changeColor(CLEAR_MOUSE_POS)
            RESTART.update(SCREEN)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30), \
                                base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if RESTART.checkForInput(CLEAR_MOUSE_POS):
                        level_6()

        if Fire_x_center<PC_x_center:
            Fire_x_pos += 2
        if Fire_x_center>PC_x_center:
            Fire_x_pos -= 2
        if Fire_y_center<PC_y_center:
            Fire_y_pos += 2
        if Fire_y_center>PC_y_center:
            Fire_y_pos -= 2

        if PC_x_pos<1000:
            if F2_x_pos<PC_x_pos:
                F2_x_pos += 2
            if F2_x_pos>PC_x_pos:
                F2_x_pos -= 2
            if F2_y_pos<PC_y_pos:
                F2_y_pos += 2
            if F2_y_pos>PC_y_pos:
                F2_y_pos -= 2

        while LEVEL_6_CLEAR == True:
            CLEAR_MOUSE_POS = pygame.mouse.get_pos()
            
            SCREEN.blit(BG, (0, 0))
            LEVEL_6_CLEAR_TEXT = get_font(45).render("Level 6 clear", True, "White")
            LEVEL_6_CLEAR_RECT = LEVEL_6_CLEAR_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(LEVEL_6_CLEAR_TEXT, LEVEL_6_CLEAR_RECT)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                            base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            LEVEL6 = Button(image=None, pos=(640,420), text_input="next level", font=get_font(30),
                            base_color="White", hovering_color="Green")
            LEVEL6.changeColor(CLEAR_MOUSE_POS)
            LEVEL6.update(SCREEN)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if LEVEL6.checkForInput(CLEAR_MOUSE_POS):
                        level_7()

                        
            pygame.display.update()

        
        
        
# 파이썬 캐릭터 움직임
            
        for event in pygame.event.get():
                
            if event.type == pygame.KEYUP:
                    
                if event.key == pygame.K_a and PC_x_pos>0  and ALIVE == True:
                    PC_x_pos -= 40
                    if PC_x_pos == 1200 and PC_y_pos != 680:
                        PC_x_pos += 40
                    if PC_x_pos == 1120 and PC_y_pos != 0:
                        PC_x_pos += 40
                    if PC_x_pos == 960 and PC_y_pos != 0:
                        PC_x_pos += 40
                    if PC_x_pos == 880 and PC_y_pos != 680:
                        PC_x_pos += 40
                    if PC_x_pos == 560:
                        PC_x_pos += 40
                        
                if event.key == pygame.K_d and PC_x_pos<1240  and ALIVE == True:
                    PC_x_pos += 40
                    if PC_x_pos == 1200 and PC_y_pos != 680:
                        PC_x_pos -= 40
                    if PC_x_pos == 1120 and PC_y_pos != 0:
                        PC_x_pos -= 40
                    if PC_x_pos == 960 and PC_y_pos != 0:
                        PC_x_pos -= 40
                    if PC_x_pos == 880 and PC_y_pos != 680:
                        PC_x_pos -= 40
                    if PC_x_pos == 560:
                        PC_x_pos -= 40
                        
                if event.key == pygame.K_w and PC_y_pos>0  and ALIVE == True:
                    PC_y_pos -= 40
                    if PC_y_pos == 640 and PC_x_pos == 1200:
                        PC_y_pos += 40
                    if PC_y_pos == 640 and PC_x_pos == 880:
                        PC_y_pos += 40
                        
                if event.key == pygame.K_s and PC_y_pos<680  and ALIVE == True:
                    PC_y_pos += 40
                    if PC_y_pos == 40 and PC_x_pos in [960, 1000, 1040, 1080, 1120]:
                        PC_y_pos -= 40

                if event.key == pygame.K_r:
                    level_6()

                if event.key == pygame.K_ESCAPE:
                    PAUSE = True

            while PAUSE == True:
                PAUSE_MOUSE_POS = pygame.mouse.get_pos()
                
                SCREEN.blit(BG, (0, 0))
                PAUSE_TEXT = get_font(45).render("paused", True, "White")
                PAUSE_RECT = PAUSE_TEXT.get_rect(center=(640, 200))
                SCREEN.blit(PAUSE_TEXT, PAUSE_RECT)
                BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOMENU.changeColor(PAUSE_MOUSE_POS)
                BACKTOMENU.update(SCREEN)
                BACKTOGAME = Button(image=None, pos=(640,420), text_input="back to game", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOGAME.changeColor(PAUSE_MOUSE_POS)
                BACKTOGAME.update(SCREEN)

                pygame.display.update()

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if BACKTOMENU.checkForInput(PAUSE_MOUSE_POS):
                            play()
                        if BACKTOGAME.checkForInput(PAUSE_MOUSE_POS):
                            PAUSE = False
                    

                        
            pygame.display.update()
                
        pygame.display.update()


def level_7():
    PC = pygame.image.load("assets/Python Character.png") # 캐릭터들 불러옴
    PC = pygame.transform.scale(PC, (40, 40))

    FC = pygame.image.load("assets/Flag Character.png")
    FC = pygame.transform.scale(FC, (40, 40))

    ROCK = pygame.image.load("assets/Rock Character.jpg")
    ROCK = pygame.transform.scale(ROCK, (80, 80))
    ROCK2 = pygame.image.load("assets/Rock Character.jpg")
    ROCK2 = pygame.transform.scale(ROCK, (40, 40))

    KEY = pygame.image.load("assets/KEY.png")
    KEY = pygame.transform.scale(KEY, (40, 40))

    Fire = pygame.image.load("assets/Fire.png")

    W1 = pygame.image.load("assets/W40x240.png")
    W2 = pygame.image.load("assets/W40x240.png")
    W3 = pygame.image.load("assets/W40x120.png")
    W4 = pygame.image.load("assets/W480x40.png")
    W5 = pygame.image.load("assets/W40x480.png")

    LEVEL_8_CLEAR = False

    
    PC_x_pos = 200
    PC_y_pos = 680
    
    FC_x_pos = 1000
    FC_y_pos = 480

    Fire_x_pos = 680
    Fire_y_pos = 440

    KEY_x_pos = 160
    KEY_y_pos = 280

    ROCK_x_pos = 240
    ROCK_y_pos = 280
    ROCK2_1_x_pos = 640
    ROCK2_1_y_pos = 160
    ROCK2_2_x_pos = 640
    ROCK2_2_y_pos = 280

    W1_1_x_pos = 80
    W1_1_y_pos = 480
    W1_2_x_pos = 120
    W1_2_y_pos = 480
    W1_3_x_pos = 400
    W1_3_y_pos = 480
    W1_4_x_pos = 440
    W1_4_y_pos = 480
    

    W2_x_pos = 640
    W2_y_pos = 320

    W3_1_x_pos = 160
    W3_1_y_pos = 400
    W3_2_x_pos = 200
    W3_2_y_pos = 400
    W3_3_x_pos = 320
    W3_3_y_pos = 400
    W3_4_x_pos = 360
    W3_4_y_pos = 400

    W4_1_x_pos = 640
    W4_1_y_pos = 120
    W4_2_x_pos = 640
    W4_2_y_pos = 560

    W5_x_pos = 1080
    W5_y_pos = 120


    PAUSE = False

    Key = 'False'
    HAVEKEY = False

    ALIVE = True

    while True:

        # 버튼 정의

        LEVEL_8_MOUSE_POS = pygame.mouse.get_pos()
        CLEAR_MOUSE_POS = pygame.mouse.get_pos()
        
        SCREEN.blit(BG, (0, 0))

        if ALIVE == True:
            SCREEN.blit(PC, (PC_x_pos, PC_y_pos))
        SCREEN.blit(FC, (FC_x_pos, FC_y_pos))

        SCREEN.blit(W1, (W1_1_x_pos, W1_1_y_pos))
        SCREEN.blit(W1, (W1_2_x_pos, W1_2_y_pos))
        SCREEN.blit(W1, (W1_3_x_pos, W1_3_y_pos))
        SCREEN.blit(W1, (W1_4_x_pos, W1_4_y_pos))
        SCREEN.blit(W2, (W2_x_pos, W2_y_pos))
        SCREEN.blit(W3, (W3_1_x_pos, W3_1_y_pos))
        SCREEN.blit(W3, (W3_2_x_pos, W3_2_y_pos))
        SCREEN.blit(W3, (W3_3_x_pos, W3_3_y_pos))
        SCREEN.blit(W3, (W3_4_x_pos, W3_4_y_pos))
        SCREEN.blit(W4, (W4_1_x_pos, W4_1_y_pos))
        SCREEN.blit(W4, (W4_2_x_pos, W4_2_y_pos))
        SCREEN.blit(W5, (W5_x_pos, W5_y_pos))
        SCREEN.blit(ROCK, (ROCK_x_pos, ROCK_y_pos))
        SCREEN.blit(ROCK2, (ROCK2_1_x_pos, ROCK2_1_y_pos))
        SCREEN.blit(ROCK2, (ROCK2_2_x_pos, ROCK2_2_y_pos))

        if HAVEKEY == False:
            SCREEN.blit(KEY, (KEY_x_pos, KEY_y_pos))

        SCREEN.blit(Fire, (Fire_x_pos, Fire_y_pos))


        LEVEL8_TEXT1 = get_font(20).render("Python = You", True, "White")
        LEVEL8_RECT1 = LEVEL8_TEXT1.get_rect(center=(160, 20))
        SCREEN.blit(LEVEL8_TEXT1, LEVEL8_RECT1)

        LEVEL8_TEXT2 = get_font(20).render("if You have Key == True:", True, "White")
        LEVEL8_RECT2 = LEVEL8_TEXT2.get_rect(center=(260, 50))
        SCREEN.blit(LEVEL8_TEXT2, LEVEL8_RECT2)

        LEVEL8_TEXT3 = get_font(20).render("Flag = Win", True, "White")
        LEVEL8_RECT3 = LEVEL8_TEXT3.get_rect(center=(150, 70))
        SCREEN.blit(LEVEL8_TEXT3, LEVEL8_RECT3) 

        LEVEL8_TEXT4 = get_font(20).render("You have Key = %s"%Key, True, "White")
        LEVEL8_RECT4 = LEVEL8_TEXT4.get_rect(center=(220, 100))
        SCREEN.blit(LEVEL8_TEXT4, LEVEL8_RECT4)

        LEVEL8_TEXT5 = get_font(20).render("Fire = Death", True, "White")
        LEVEL8_RECT5 = LEVEL8_TEXT5.get_rect(center=(160, 130))
        SCREEN.blit(LEVEL8_TEXT5, LEVEL8_RECT5)
        
        LEVEL8_TEXT6 = get_font(20).render("Wall = Stop", True, "White")
        LEVEL8_RECT6 = LEVEL8_TEXT6.get_rect(center=(150, 160))
        SCREEN.blit(LEVEL8_TEXT6, LEVEL8_RECT6)

        LEVEL8_TEXT7 = get_font(20).render("Rock = Defeat", True, "White")
        LEVEL8_RECT7 = LEVEL8_TEXT7.get_rect(center=(170, 190))
        SCREEN.blit(LEVEL8_TEXT7, LEVEL8_RECT7)
        PC_x_center = PC_x_pos + 20
        PC_y_center = PC_y_pos + 20
        Fire_x_center = Fire_x_pos + 20
        Fire_y_center = Fire_y_pos + 20
            

        if PC_x_pos == FC_x_pos and PC_y_pos == FC_y_pos and HAVEKEY == True and ALIVE == True: #클리어 조건
            LEVEL_8_CLEAR = True
        if (PC_x_pos in [240, 280] and PC_y_pos in [280, 320]) \
           or (PC_x_pos == 640 and PC_y_pos ==160) or (PC_x_pos == 640 and PC_y_pos ==280):
            SCREEN.blit(BG, (0, 0))
            GAME_OVER_TEXT = get_font(45).render("GAME OVER", True, "White")
            GAME_OVER_RECT = GAME_OVER_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(GAME_OVER_TEXT, GAME_OVER_RECT)
            RESTART = Button(image=None, pos=(640,420), text_input="Restart", font=get_font(30), \
                             base_color="White", hovering_color="Green")
            RESTART.changeColor(CLEAR_MOUSE_POS)
            RESTART.update(SCREEN)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30), \
                                base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if RESTART.checkForInput(CLEAR_MOUSE_POS):
                        level_8()

        if PC_x_pos == KEY_x_pos and PC_y_pos == KEY_y_pos:
            Key = 'True'
            HAVEKEY = True

        if (-17<Fire_x_center-PC_x_center<17 and -17<Fire_y_center-PC_y_center<17):
            ALIVE = False
        if ALIVE == False:
            SCREEN.blit(BG, (0, 0))
            GAME_OVER_TEXT = get_font(45).render("GAME OVER", True, "White")
            GAME_OVER_RECT = GAME_OVER_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(GAME_OVER_TEXT, GAME_OVER_RECT)
            RESTART = Button(image=None, pos=(640,420), text_input="Restart", font=get_font(30), \
                             base_color="White", hovering_color="Green")
            RESTART.changeColor(CLEAR_MOUSE_POS)
            RESTART.update(SCREEN)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30), \
                                base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if RESTART.checkForInput(CLEAR_MOUSE_POS):
                        level_8()

        if PC_x_pos>640:
            if Fire_x_pos<PC_x_pos:
                Fire_x_pos += 4
            if Fire_x_pos>PC_x_pos:
                Fire_x_pos -= 4
            if Fire_y_pos<PC_y_pos:
                Fire_y_pos += 4
            if Fire_y_pos>PC_y_pos:
                Fire_y_pos -= 4

        while LEVEL_8_CLEAR == True:
            CLEAR_MOUSE_POS = pygame.mouse.get_pos()
            
            SCREEN.blit(BG, (0, 0))
            LEVEL_8_CLEAR_TEXT = get_font(45).render("Level 8 clear", True, "White")
            LEVEL_8_CLEAR_RECT = LEVEL_8_CLEAR_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(LEVEL_8_CLEAR_TEXT, LEVEL_8_CLEAR_RECT)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                            base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            LEVEL9 = Button(image=None, pos=(640,420), text_input="next level", font=get_font(30),
                            base_color="White", hovering_color="Green")
            LEVEL9.changeColor(CLEAR_MOUSE_POS)
            LEVEL9.update(SCREEN)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if LEVEL9.checkForInput(CLEAR_MOUSE_POS):
                        level_9()

                        
            pygame.display.update()

# 파이썬 캐릭터 움직임
            
        for event in pygame.event.get():
                
            if event.type == pygame.KEYUP:
                    
                if event.key == pygame.K_a and PC_x_pos>0  and ALIVE == True:
                    PC_x_pos -= 40
                    if PC_x_pos in [120, 440] and PC_y_pos in [480,520,560,600,640,680]:
                        PC_x_pos += 40
                    if PC_x_pos in [200,360] and PC_y_pos in [400,440,480]:
                        PC_x_pos += 40
                    if PC_x_pos == 640 and PC_y_pos in range(320,560, 40):
                        PC_x_pos += 40
                    if PC_x_pos == 1080 and PC_y_pos not in [0,40,80,600,640,680]:
                        PC_x_pos += 40
          
                if event.key == pygame.K_d and PC_x_pos<1240  and ALIVE == True:
                    PC_x_pos += 40
                    if PC_x_pos in [80,400] and PC_y_pos in [480,520,560,600,640,680]:
                        PC_x_pos -= 40
                    if PC_x_pos in [160, 320] and PC_y_pos in [400,440,480]:
                        PC_x_pos -= 40
                    if PC_x_pos == 640 and PC_y_pos in range(320,560, 40):
                        PC_x_pos -= 40
                    if PC_x_pos == 1080 and PC_y_pos not in [0,40,80,600,640,680]:
                        PC_x_pos -= 40
                        
                if event.key == pygame.K_w and PC_y_pos>0  and ALIVE == True:
                    PC_y_pos -= 40
                    if PC_y_pos == 480 and PC_x_pos in [160,200,320,360]:
                        PC_y_pos += 40
                    if PC_y_pos in [120,560] and PC_x_pos in range(640,1120,40):
                        PC_y_pos += 40
                        
                if event.key == pygame.K_s and PC_y_pos<680  and ALIVE == True:
                    PC_y_pos += 40
                    if PC_y_pos == 480 and PC_x_pos in [80, 120, 400, 440]:
                        PC_y_pos -= 40
                    if PC_y_pos in [120,560] and PC_x_pos in range(640,1120,40):
                        PC_y_pos -= 40

                if event.key == pygame.K_r:
                    level_8()

                if event.key == pygame.K_ESCAPE:
                    PAUSE = True

            while PAUSE == True:
                PAUSE_MOUSE_POS = pygame.mouse.get_pos()
                
                SCREEN.blit(BG, (0, 0))
                PAUSE_TEXT = get_font(45).render("paused", True, "White")
                PAUSE_RECT = PAUSE_TEXT.get_rect(center=(640, 200))
                SCREEN.blit(PAUSE_TEXT, PAUSE_RECT)
                BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOMENU.changeColor(PAUSE_MOUSE_POS)
                BACKTOMENU.update(SCREEN)
                BACKTOGAME = Button(image=None, pos=(640,420), text_input="back to game", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOGAME.changeColor(PAUSE_MOUSE_POS)
                BACKTOGAME.update(SCREEN)

                pygame.display.update()

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if BACKTOMENU.checkForInput(PAUSE_MOUSE_POS):
                            play()
                        if BACKTOGAME.checkForInput(PAUSE_MOUSE_POS):
                            PAUSE = False
                    

                        
            pygame.display.update()
                
        pygame.display.update()


def level_8():

    pygame.init()
    
    PC = pygame.image.load("assets/Python Character.png") # 캐릭터들 불러옴
    PC = pygame.transform.scale(PC, (40, 40))

    FC = pygame.image.load("assets/Flag Character.png")
    FC = pygame.transform.scale(FC, (40, 40))

    ROCK = pygame.image.load("assets/Rock Character.jpg")
    ROCK = pygame.transform.scale(ROCK, (80, 80))
    ROCK2 = pygame.image.load("assets/Rock Character.jpg")
    ROCK2 = pygame.transform.scale(ROCK, (40, 40))

    KEY = pygame.image.load("assets/KEY.png")
    KEY = pygame.transform.scale(KEY, (40, 40))

    BH = pygame.image.load("assets/Blackhole.png")
    BH = pygame.transform.scale(BH, (40, 40))

    WH = pygame.image.load("assets/Whitehole.png")
    WH = pygame.transform.scale(WH, (40, 40))

    Fire = pygame.image.load("assets/Fire.png")

    W1 = pygame.image.load("assets/W40x120.png")
    W2 = pygame.image.load("assets/W120x40.png")
    W3 = pygame.image.load("assets/W40x360.png")
    W4 = pygame.image.load("assets/W240x40.png")

    LEVEL_9_CLEAR = False

    
    PC_x_pos = 1200
    PC_y_pos = 40
    
    FC_x_pos = 640
    FC_y_pos = 40

    BH_x_pos = 840
    BH_y_pos = 640

    WH_x_pos = 120
    WH_y_pos = 400

    Fire_x_pos = 1040
    Fire_y_pos = 240

    KEY_x_pos = 360
    KEY_y_pos = 560

    W1_1_x_pos = 280
    W1_1_y_pos = 480
    W1_2_x_pos = 440
    W1_2_y_pos = 480
    W1_3_x_pos = 720
    W1_3_y_pos = 0
    W1_4_x_pos = 520
    W1_4_y_pos = 240
    
    W2_1_x_pos = 280
    W2_1_y_pos = 600
    W2_2_x_pos = 360
    W2_2_y_pos = 600
    W2_3_x_pos = 240
    W2_3_y_pos = 120
    W2_4_x_pos = 440
    W2_4_y_pos = 120
    
    W3_1_x_pos = 240
    W3_1_y_pos = 0

    W4_1_x_pos = 280
    W4_1_y_pos = 280
    W4_2_x_pos = 520
    W4_2_y_pos = 80


    PAUSE = False

    Key = 'False'
    HAVEKEY = False

    ALIVE = True

    while True:

        # 버튼 정의

        LEVEL_9_MOUSE_POS = pygame.mouse.get_pos()
        CLEAR_MOUSE_POS = pygame.mouse.get_pos()
        
        SCREEN.blit(BG, (0, 0))

        if ALIVE == True:
            SCREEN.blit(PC, (PC_x_pos, PC_y_pos))
        SCREEN.blit(FC, (FC_x_pos, FC_y_pos))

        SCREEN.blit(W1, (W1_1_x_pos, W1_1_y_pos))
        SCREEN.blit(W1, (W1_2_x_pos, W1_2_y_pos))
        SCREEN.blit(W1, (W1_3_x_pos, W1_3_y_pos))
        SCREEN.blit(W1, (W1_4_x_pos, W1_4_y_pos))
        SCREEN.blit(W2, (W2_1_x_pos, W2_1_y_pos))
        SCREEN.blit(W2, (W2_2_x_pos, W2_2_y_pos))
        SCREEN.blit(W2, (W2_3_x_pos, W2_3_y_pos))
        SCREEN.blit(W2, (W2_4_x_pos, W2_4_y_pos))
        SCREEN.blit(W3, (W3_1_x_pos, W3_1_y_pos))
        SCREEN.blit(W4, (W4_1_x_pos, W4_1_y_pos))
        SCREEN.blit(W4, (W4_2_x_pos, W4_2_y_pos))
        
        SCREEN.blit(BH, (BH_x_pos, BH_y_pos))
        SCREEN.blit(WH, (WH_x_pos, WH_y_pos))
        
        for i in range (680, 1040, 40):
            SCREEN.blit(ROCK, (i, 640-(80*((i-680)/40))))
        for j in range (760, 1120, 40):
            SCREEN.blit(ROCK, (j, 640-(80*((j-760)/40))))
        SCREEN.blit(ROCK2, (320, 520))
        SCREEN.blit(ROCK2, (400, 520))

        if HAVEKEY == False:
            SCREEN.blit(KEY, (KEY_x_pos, KEY_y_pos))

        SCREEN.blit(Fire, (Fire_x_pos, Fire_y_pos))


        LEVEL9_TEXT1 = get_font(20).render("Python = You", True, "White")
        LEVEL9_RECT1 = LEVEL9_TEXT1.get_rect(center=(160, 20))
        SCREEN.blit(LEVEL9_TEXT1, LEVEL9_RECT1)

        LEVEL9_TEXT2 = get_font(20).render("if You have Key == True:", True, "White")
        LEVEL9_RECT2 = LEVEL9_TEXT2.get_rect(center=(260, 50))
        SCREEN.blit(LEVEL9_TEXT2, LEVEL9_RECT2)

        LEVEL9_TEXT3 = get_font(20).render("Flag = Win", True, "White")
        LEVEL9_RECT3 = LEVEL9_TEXT3.get_rect(center=(150, 70))
        SCREEN.blit(LEVEL9_TEXT3, LEVEL9_RECT3) 

        LEVEL9_TEXT4 = get_font(20).render("You have Key = %s"%Key, True, "White")
        LEVEL9_RECT4 = LEVEL9_TEXT4.get_rect(center=(220, 100))
        SCREEN.blit(LEVEL9_TEXT4, LEVEL9_RECT4)

        LEVEL9_TEXT5 = get_font(20).render("Fire = Death", True, "White")
        LEVEL9_RECT5 = LEVEL9_TEXT5.get_rect(center=(160, 130))
        SCREEN.blit(LEVEL9_TEXT5, LEVEL9_RECT5)
        
        LEVEL9_TEXT6 = get_font(20).render("Wall = Stop", True, "White")
        LEVEL9_RECT6 = LEVEL9_TEXT6.get_rect(center=(150, 160))
        SCREEN.blit(LEVEL9_TEXT6, LEVEL9_RECT6)

        LEVEL9_TEXT7 = get_font(20).render("Rock = Defeat", True, "White")
        LEVEL9_RECT7 = LEVEL9_TEXT7.get_rect(center=(170, 190))
        SCREEN.blit(LEVEL9_TEXT7, LEVEL9_RECT7)

        LEVEL9_TEXT8 = get_font(20).render("Blackhole = Teleport", True, "White")
        LEVEL9_RECT8 = LEVEL9_TEXT2.get_rect(center=(260, 220))
        SCREEN.blit(LEVEL9_TEXT8, LEVEL9_RECT8)
        
        PC_x_center = PC_x_pos + 20
        PC_y_center = PC_y_pos + 20
        Fire_x_center = Fire_x_pos + 20
        Fire_y_center = Fire_y_pos + 20

        if BH_x_pos == 840:
            BH_y_pos += 10   

        if BH_x_pos == 1240:
            BH_y_pos -= 10

        if BH_y_pos == 680:
            BH_x_pos += 10

        if BH_y_pos == 640:
            BH_x_pos -= 10

        if PC_x_pos == FC_x_pos and PC_y_pos == FC_y_pos and HAVEKEY == True and ALIVE == True: #클리어 조건
            LEVEL_9_CLEAR = True
        if (PC_x_pos in [1000, 1120] and PC_y_pos in [0, 40]) \
           or (PC_x_pos in [960, 1080] and PC_y_pos in [80, 120]) \
           or (PC_x_pos in [920, 1040] and PC_y_pos in [160, 200]) \
           or (PC_x_pos in [880, 1000] and PC_y_pos in [240, 280]) \
           or (PC_x_pos in [840, 960] and PC_y_pos in [320, 360]) \
           or (PC_x_pos in [800, 920] and PC_y_pos in [400, 440]) \
           or (PC_x_pos in [760, 880] and PC_y_pos in [480, 520]) \
           or (PC_x_pos in [720, 840] and PC_y_pos in [560, 600]) \
           or (PC_x_pos in [680, 800] and PC_y_pos in [640, 680])\
           or (PC_x_pos in [320, 400] and PC_y_pos == 520):
            SCREEN.blit(BG, (0, 0))
            GAME_OVER_TEXT = get_font(45).render("GAME OVER", True, "White")
            GAME_OVER_RECT = GAME_OVER_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(GAME_OVER_TEXT, GAME_OVER_RECT)
            RESTART = Button(image=None, pos=(640,420), text_input="Restart", font=get_font(30), \
                             base_color="White", hovering_color="Green")
            RESTART.changeColor(CLEAR_MOUSE_POS)
            RESTART.update(SCREEN)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30), \
                                base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if RESTART.checkForInput(CLEAR_MOUSE_POS):
                        level_9()

        if PC_x_pos == KEY_x_pos and PC_y_pos == KEY_y_pos:
            Key = 'True'
            HAVEKEY = True
            
        if PC_x_pos == BH_x_pos and PC_y_pos == BH_y_pos:
            PC_x_pos = WH_x_pos
            PC_y_pos = WH_y_pos

        if (-17<Fire_x_center-PC_x_center<17 and -17<Fire_y_center-PC_y_center<17):
            ALIVE = False
        if ALIVE == False:
            SCREEN.blit(BG, (0, 0))
            GAME_OVER_TEXT = get_font(45).render("GAME OVER", True, "White")
            GAME_OVER_RECT = GAME_OVER_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(GAME_OVER_TEXT, GAME_OVER_RECT)
            RESTART = Button(image=None, pos=(640,420), text_input="Restart", font=get_font(30), \
                             base_color="White", hovering_color="Green")
            RESTART.changeColor(CLEAR_MOUSE_POS)
            RESTART.update(SCREEN)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30), \
                                base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if RESTART.checkForInput(CLEAR_MOUSE_POS):
                        level_9()
                        
        if Fire_x_center<PC_x_center and PC_x_pos > 840:
            Fire_x_pos += 3
        if Fire_x_center>PC_x_center and PC_x_pos > 840:
            Fire_x_pos -= 3
        if Fire_y_center<PC_y_center and PC_x_pos > 840:
            Fire_y_pos += 3
        if Fire_y_center>PC_y_center and PC_x_pos > 840:
            Fire_y_pos -= 3
            

        while LEVEL_9_CLEAR == True:
            CLEAR_MOUSE_POS = pygame.mouse.get_pos()
            
            SCREEN.blit(BG, (0, 0))
            LEVEL_9_CLEAR_TEXT = get_font(45).render("Level 8 clear", True, "White")
            LEVEL_9_CLEAR_RECT = LEVEL_9_CLEAR_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(LEVEL_9_CLEAR_TEXT, LEVEL_9_CLEAR_RECT)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                            base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            LEVEL10 = Button(image=None, pos=(640,420), text_input="next level", font=get_font(30),
                            base_color="White", hovering_color="Green")
            LEVEL10.changeColor(CLEAR_MOUSE_POS)
            LEVEL10.update(SCREEN)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if LEVEL10.checkForInput(CLEAR_MOUSE_POS):
                        level_9()

                        
            pygame.display.update()

# 파이썬 캐릭터 움직임
            
        for event in pygame.event.get():
                
            if event.type == pygame.KEYUP:
                    
                if event.key == pygame.K_a and PC_x_pos>0  and ALIVE == True:
                    PC_x_pos -= 40
                    if PC_x_pos in [280, 440] and PC_y_pos in [480,520,560, 600]:
                        PC_x_pos += 40
                    if PC_x_pos == 240 and PC_y_pos in range(0, 360, 40):
                        PC_x_pos += 40
                    if PC_x_pos == 520 and PC_y_pos in [120,240,280,320]:
                        PC_x_pos += 40
                    if PC_x_pos == 720 and PC_y_pos in [0,80,120]:
                        PC_x_pos += 40
                    if PC_x_pos == 320 and PC_y_pos == 120:
                        PC_x_pos += 40
          
                if event.key == pygame.K_d and PC_x_pos<1240  and ALIVE == True:
                    PC_x_pos += 40
                    if PC_x_pos in [280,440] and PC_y_pos in [480,520,560,600]:
                        PC_x_pos -= 40
                    if PC_x_pos == 240 and PC_y_pos in range(0,360, 40):
                        PC_x_pos -= 40
                    if PC_x_pos == 520 and PC_y_pos in [80,120,240,280,320]:
                        PC_x_pos -= 40
                    if PC_x_pos == 720 and PC_y_pos in [0,80]:
                        PC_x_pos -= 40
                    if PC_x_pos == 440 and PC_y_pos == 120:
                        PC_x_pos -= 40 
                        
                if event.key == pygame.K_w and PC_y_pos>0  and ALIVE == True:
                    PC_y_pos -= 40
                    if PC_y_pos == 120 and PC_x_pos in [280,320,440,480,520]:
                        PC_y_pos += 40
                    if PC_y_pos == 80 and PC_x_pos in range(520,760,40):
                        PC_y_pos += 40
                    if PC_y_pos == 280 and PC_x_pos in range(280,560,40):
                        PC_y_pos += 40
                    if PC_y_pos == 600 and PC_x_pos in range(280,480,40):
                        PC_y_pos += 40
                    if PC_y_pos == 320 and PC_x_pos in [240, 520]:
                        PC_y_pos += 40
                    
                    
                        
                if event.key == pygame.K_s and PC_y_pos<680  and ALIVE == True:
                    PC_y_pos += 40
                    if PC_y_pos == 120 and PC_x_pos in [280,320,440,480]:
                        PC_y_pos -= 40
                    if PC_y_pos == 80 and PC_x_pos in range(520,760,40):
                        PC_y_pos -= 40
                    if PC_y_pos == 280 and PC_x_pos in range(280,560,40):
                        PC_y_pos -= 40
                    if PC_y_pos == 600 and PC_x_pos in range(280,480,40):
                        PC_y_pos -= 40

                if event.key == pygame.K_r:
                    level_8()

                if event.key == pygame.K_ESCAPE:
                    PAUSE = True

            while PAUSE == True:
                PAUSE_MOUSE_POS = pygame.mouse.get_pos()
                
                SCREEN.blit(BG, (0, 0))
                PAUSE_TEXT = get_font(45).render("paused", True, "White")
                PAUSE_RECT = PAUSE_TEXT.get_rect(center=(640, 200))
                SCREEN.blit(PAUSE_TEXT, PAUSE_RECT)
                BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOMENU.changeColor(PAUSE_MOUSE_POS)
                BACKTOMENU.update(SCREEN)
                BACKTOGAME = Button(image=None, pos=(640,420), text_input="back to game", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOGAME.changeColor(PAUSE_MOUSE_POS)
                BACKTOGAME.update(SCREEN)

                pygame.display.update()

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if BACKTOMENU.checkForInput(PAUSE_MOUSE_POS):
                            play()
                        if BACKTOGAME.checkForInput(PAUSE_MOUSE_POS):
                            PAUSE = False
                    

                        
            pygame.display.update()
                
        pygame.display.update()



def level_9():
    PC = pygame.image.load("assets/Python Character.png") # 캐릭터들 불러옴
    PC = pygame.transform.scale(PC, (40, 40))

    FC = pygame.image.load("assets/Flag Character.png")
    FC = pygame.transform.scale(FC, (40, 40))

    KEY = pygame.image.load("assets/KEY.png")
    KEY = pygame.transform.scale(KEY, (40, 40))

    BH = pygame.image.load("assets/Blackhole.png")
    BH = pygame.transform.scale(BH, (40, 40))

    WH = pygame.image.load("assets/Whitehole.png")
    WH = pygame.transform.scale(WH, (40, 40))

    Fire = pygame.image.load("assets/Fire.png")

    Water = pygame.image.load("assets/Water.png")

    W1 = pygame.image.load("assets/W40x120.png")
    W2 = pygame.image.load("assets/W120x40.png")
    W3 = pygame.image.load("assets/W40x360.png")
    W4 = pygame.image.load("assets/W240x40.png")

    LEVEL_9_CLEAR = False

    
    PC_x_pos = 1200
    PC_y_pos = 40
    
    FC_x_pos = 600
    FC_y_pos = 0

    BH1_x_pos = 840
    BH1_y_pos = 640

    BH2_x_pos = 200
    BH2_y_pos = 520

    WH1_x_pos = 120
    WH1_y_pos = 520

    WH2_x_pos = 160
    WH2_y_pos = 440

    FF1_x_pos = 560
    FF1_y_pos = 0
    FF2_x_pos = 560
    FF2_y_pos = 40
    FF3_x_pos = 600
    FF3_y_pos = 40
    FF4_x_pos = 640
    FF4_y_pos = 40
    FF5_x_pos = 640
    FF5_y_pos = 0

    Fire1_x_pos = random.randint(320, 1000)
    Fire1_y_pos = random.randint(0, 480)

    Fire2_x_pos = random.randint(320, 1000)
    Fire2_y_pos = random.randint(0, 480)

    Fire3_x_pos = random.randint(320, 1240)
    Fire3_y_pos = random.randint(360, 680)

    Fire4_x_pos = random.randint(320, 1240)
    Fire4_y_pos = random.randint(360, 680)

    Water_x_pos = 160
    Water_y_pos = 520

    KEY_x_pos = 360
    KEY_y_pos = 560

    W1_1_x_pos = 80
    W1_1_y_pos = 480
    W1_2_x_pos = 240
    W1_2_y_pos = 480
    
    W2_1_x_pos = 120
    W2_1_y_pos = 480
    W2_2_x_pos = 120
    W2_2_y_pos = 560
    


    PAUSE = False

    Key = 'False'
    HAVEKEY = False

    W = 'False'
    YAW = False

    ALIVE = True

    while True:


        # 버튼 정의

        LEVEL_9_MOUSE_POS = pygame.mouse.get_pos()
        CLEAR_MOUSE_POS = pygame.mouse.get_pos()
        
        SCREEN.blit(BG, (0, 0))

        if ALIVE == True:
            SCREEN.blit(PC, (PC_x_pos, PC_y_pos))
        SCREEN.blit(FC, (FC_x_pos, FC_y_pos))

        SCREEN.blit(W1, (W1_1_x_pos, W1_1_y_pos))
        SCREEN.blit(W1, (W1_2_x_pos, W1_2_y_pos))
        SCREEN.blit(W2, (W2_1_x_pos, W2_1_y_pos))
        SCREEN.blit(W2, (W2_2_x_pos, W2_2_y_pos))

        
        SCREEN.blit(BH, (BH1_x_pos, BH1_y_pos))
        SCREEN.blit(WH, (WH1_x_pos, WH1_y_pos))
        SCREEN.blit(BH, (BH2_x_pos, BH2_y_pos))
        SCREEN.blit(WH, (WH2_x_pos, WH2_y_pos))
        

        if HAVEKEY == False:
            SCREEN.blit(KEY, (KEY_x_pos, KEY_y_pos))

        SCREEN.blit(Fire, (Fire1_x_pos, Fire1_y_pos))
        SCREEN.blit(Fire, (Fire2_x_pos, Fire2_y_pos))
        SCREEN.blit(Fire, (Fire3_x_pos, Fire3_y_pos))
        SCREEN.blit(Fire, (Fire4_x_pos, Fire4_y_pos))
        SCREEN.blit(Fire, (FF1_x_pos, FF1_y_pos))
        SCREEN.blit(Fire, (FF2_x_pos, FF2_y_pos))
        SCREEN.blit(Fire, (FF3_x_pos, FF3_y_pos))
        SCREEN.blit(Fire, (FF4_x_pos, FF4_y_pos))
        SCREEN.blit(Fire, (FF5_x_pos, FF5_y_pos))

        if YAW == False:
            SCREEN.blit(Water, (Water_x_pos, Water_y_pos))


        LEVEL9_TEXT1 = get_font(20).render("Python = You", True, "White")
        LEVEL9_RECT1 = LEVEL9_TEXT1.get_rect(center=(160, 20))
        SCREEN.blit(LEVEL9_TEXT1, LEVEL9_RECT1)

        LEVEL9_TEXT2 = get_font(20).render("if You have Key == True:", True, "White")
        LEVEL9_RECT2 = LEVEL9_TEXT2.get_rect(center=(260, 50))
        SCREEN.blit(LEVEL9_TEXT2, LEVEL9_RECT2)

        LEVEL9_TEXT3 = get_font(20).render("Flag = Win", True, "White")
        LEVEL9_RECT3 = LEVEL9_TEXT3.get_rect(center=(150, 70))
        SCREEN.blit(LEVEL9_TEXT3, LEVEL9_RECT3) 

        LEVEL9_TEXT4 = get_font(20).render("You have Key = %s"%Key, True, "White")
        LEVEL9_RECT4 = LEVEL9_TEXT4.get_rect(center=(220, 100))
        SCREEN.blit(LEVEL9_TEXT4, LEVEL9_RECT4)

        LEVEL9_TEXT5 = get_font(20).render("Fire = Death", True, "White")
        LEVEL9_RECT5 = LEVEL9_TEXT5.get_rect(center=(160, 130))
        SCREEN.blit(LEVEL9_TEXT5, LEVEL9_RECT5)
        
        LEVEL9_TEXT6 = get_font(20).render("Wall = Stop", True, "White")
        LEVEL9_RECT6 = LEVEL9_TEXT6.get_rect(center=(150, 160))
        SCREEN.blit(LEVEL9_TEXT6, LEVEL9_RECT6)

        LEVEL9_TEXT7 = get_font(20).render("If You_are_Water == True:", True, "White")
        LEVEL9_RECT7 = LEVEL9_TEXT7.get_rect(center=(280, 190))
        SCREEN.blit(LEVEL9_TEXT7, LEVEL9_RECT7)

        LEVEL9_TEXT9 = get_font(20).render("Fire != Death", True, "White")
        LEVEL9_RECT9 = LEVEL9_TEXT9.get_rect(center=(220, 220))
        SCREEN.blit(LEVEL9_TEXT9, LEVEL9_RECT9)

        LEVEL9_TEXT10 = get_font(20).render("You_are_Water = %s"%W, True, "White")
        LEVEL9_RECT10 = LEVEL9_TEXT10.get_rect(center=(240, 250))
        SCREEN.blit(LEVEL9_TEXT10, LEVEL9_RECT10)

        LEVEL9_TEXT8 = get_font(20).render("Blackhole = Teleport", True, "White")
        LEVEL9_RECT8 = LEVEL9_TEXT8.get_rect(center=(260, 280))
        SCREEN.blit(LEVEL9_TEXT8, LEVEL9_RECT8)


        if PC_x_pos == FC_x_pos and PC_y_pos == FC_y_pos and HAVEKEY == True and ALIVE == True: #클리어 조건
            LEVEL_9_CLEAR = True


        if PC_x_pos == KEY_x_pos and PC_y_pos == KEY_y_pos:
            Key = 'True'
            HAVEKEY = True

        if PC_x_pos == Water_x_pos and PC_y_pos == Water_y_pos:
            W = 'True'
            YAW = True
            
        if PC_x_pos == BH1_x_pos and PC_y_pos == BH1_y_pos:
            PC_x_pos = WH1_x_pos
            PC_y_pos = WH1_y_pos

        if PC_x_pos == BH2_x_pos and PC_y_pos == BH2_y_pos:
            PC_x_pos = WH2_x_pos
            PC_y_pos = WH2_y_pos

        if (-17<Fire1_x_pos-PC_x_pos<17 and -17<Fire1_y_pos-PC_y_pos<17) and YAW == False:
            ALIVE = False
        if (-17<Fire2_x_pos-PC_x_pos<17 and -17<Fire2_y_pos-PC_y_pos<17) and YAW == False:
            ALIVE = False
        if (-17<Fire3_x_pos-PC_x_pos<17 and -17<Fire3_y_pos-PC_y_pos<17) and YAW == False:
            ALIVE = False
        if (-17<Fire4_x_pos-PC_x_pos<17 and -17<Fire4_y_pos-PC_y_pos<17) and YAW == False:
            ALIVE = False
        if (-17<FF1_x_pos-PC_x_pos<17 and -17<FF1_y_pos-PC_y_pos<17) and YAW == False:
            ALIVE = False
        if (-17<FF2_x_pos-PC_x_pos<17 and -17<FF2_y_pos-PC_y_pos<17) and YAW == False:
            ALIVE = False
        if (-17<FF3_x_pos-PC_x_pos<17 and -17<FF3_y_pos-PC_y_pos<17) and YAW == False:
            ALIVE = False
        if (-17<FF4_x_pos-PC_x_pos<17 and -17<FF4_y_pos-PC_y_pos<17) and YAW == False:
            ALIVE = False
        if (-17<FF5_x_pos-PC_x_pos<17 and -17<FF5_y_pos-PC_y_pos<17) and YAW == False:
            ALIVE = False
            
        if ALIVE == False:
            SCREEN.blit(BG, (0, 0))
            GAME_OVER_TEXT = get_font(45).render("GAME OVER", True, "White")
            GAME_OVER_RECT = GAME_OVER_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(GAME_OVER_TEXT, GAME_OVER_RECT)
            RESTART = Button(image=None, pos=(640,420), text_input="Restart", font=get_font(30), \
                             base_color="White", hovering_color="Green")
            RESTART.changeColor(CLEAR_MOUSE_POS)
            RESTART.update(SCREEN)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30), \
                                base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if RESTART.checkForInput(CLEAR_MOUSE_POS):
                        level_9()
                        
        if Fire1_x_pos<PC_x_pos:
            Fire1_x_pos += random.randint(2,5)
        if Fire1_x_pos>PC_x_pos:
            Fire1_x_pos -= random.randint(2,5)
        if Fire1_y_pos<PC_y_pos:
            Fire1_y_pos += random.randint(2,5)
        if Fire1_y_pos>PC_y_pos:
            Fire1_y_pos -= random.randint(2,5)
        if Fire2_x_pos<PC_x_pos:
            Fire2_x_pos += random.randint(2,5)
        if Fire2_x_pos>PC_x_pos:
            Fire2_x_pos -= random.randint(2,5)
        if Fire2_y_pos<PC_y_pos:
            Fire2_y_pos += random.randint(2,5)
        if Fire2_y_pos>PC_y_pos:
            Fire2_y_pos -= random.randint(2,5)
        if Fire3_x_pos<PC_x_pos:
            Fire3_x_pos += random.randint(2,5)
        if Fire3_x_pos>PC_x_pos:
            Fire3_x_pos -= random.randint(2,5)
        if Fire3_y_pos<PC_y_pos:
            Fire3_y_pos += random.randint(2,5)
        if Fire3_y_pos>PC_y_pos:
            Fire3_y_pos -= random.randint(2,5)
        if Fire4_x_pos<PC_x_pos:
            Fire4_x_pos += random.randint(2,5)
        if Fire4_x_pos>PC_x_pos:
            Fire4_x_pos -= random.randint(2,5)
        if Fire4_y_pos<PC_y_pos:
            Fire4_y_pos += random.randint(2,5)
        if Fire4_y_pos>PC_y_pos:
            Fire4_y_pos -= random.randint(2,5)
            

        while LEVEL_9_CLEAR == True:
            CLEAR_MOUSE_POS = pygame.mouse.get_pos()
            
            SCREEN.blit(BG, (0, 0))
            LEVEL_9_CLEAR_TEXT = get_font(45).render("Level 9 clear", True, "White")
            LEVEL_9_CLEAR_RECT = LEVEL_9_CLEAR_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(LEVEL_9_CLEAR_TEXT, LEVEL_9_CLEAR_RECT)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                            base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            LEVEL10 = Button(image=None, pos=(640,420), text_input="next level", font=get_font(30),
                            base_color="White", hovering_color="Green")
            LEVEL10.changeColor(CLEAR_MOUSE_POS)
            LEVEL10.update(SCREEN)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if LEVEL10.checkForInput(CLEAR_MOUSE_POS):
                        level_10()

                        
            pygame.display.update()

# 파이썬 캐릭터 움직임
            
        for event in pygame.event.get():
                
            if event.type == pygame.KEYUP:
                    
                if event.key == pygame.K_a and PC_x_pos>0  and ALIVE == True:
                    PC_x_pos -= 40
                    if PC_x_pos == 240 and PC_y_pos in [480, 520, 560]:
                        PC_x_pos += 40
                    elif PC_x_pos == 80 and PC_y_pos == 520:
                        PC_x_pos += 40
          
                if event.key == pygame.K_d and PC_x_pos<1240  and ALIVE == True:
                    PC_x_pos += 40
                    if PC_x_pos == 80 and PC_y_pos in [480,520,560]:
                        PC_x_pos -= 40
                    elif PC_x_pos == 240 and PC_y_pos ==520:
                        PC_x_pos -= 40

                        
                if event.key == pygame.K_w and PC_y_pos>0  and ALIVE == True:
                    PC_y_pos -= 40
                    if PC_y_pos == 480 and PC_x_pos in [120, 160, 200]:
                        PC_y_pos += 40
                    elif PC_y_pos == 560 and PC_x_pos in [120, 160, 200]:
                        PC_y_pos += 40
                    
                        
                if event.key == pygame.K_s and PC_y_pos<680  and ALIVE == True:
                    PC_y_pos += 40
                    if PC_y_pos == 480 and PC_x_pos in [120, 160, 200]:
                        PC_y_pos -= 40
                    elif PC_y_pos == 560 and PC_x_pos in [120, 160, 200]:
                        PC_y_pos -= 40


                if event.key == pygame.K_r:
                    level_9()

                if event.key == pygame.K_ESCAPE:
                    PAUSE = True

            while PAUSE == True:
                PAUSE_MOUSE_POS = pygame.mouse.get_pos()
                
                SCREEN.blit(BG, (0, 0))
                PAUSE_TEXT = get_font(45).render("paused", True, "White")
                PAUSE_RECT = PAUSE_TEXT.get_rect(center=(640, 200))
                SCREEN.blit(PAUSE_TEXT, PAUSE_RECT)
                BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOMENU.changeColor(PAUSE_MOUSE_POS)
                BACKTOMENU.update(SCREEN)
                BACKTOGAME = Button(image=None, pos=(640,420), text_input="back to game", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOGAME.changeColor(PAUSE_MOUSE_POS)
                BACKTOGAME.update(SCREEN)

                pygame.display.update()

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if BACKTOMENU.checkForInput(PAUSE_MOUSE_POS):
                            play()
                        if BACKTOGAME.checkForInput(PAUSE_MOUSE_POS):
                            PAUSE = False
                    

                        
            pygame.display.update()
                
        pygame.display.update()






def level_10():
    PC = pygame.image.load("assets/Python Character.png") # 캐릭터들 불러옴
    PC = pygame.transform.scale(PC, (40, 40))

    FC = pygame.image.load("assets/Flag Character.png")
    FC = pygame.transform.scale(FC, (40, 40))

    KEY = pygame.image.load("assets/KEY.png")
    KEY = pygame.transform.scale(KEY, (40, 40))

    BH = pygame.image.load("assets/Blackhole.png")
    BH = pygame.transform.scale(BH, (40, 40))

    WH = pygame.image.load("assets/Whitehole.png")
    WH = pygame.transform.scale(WH, (40, 40))

    Fire = pygame.image.load("assets/Fire.png")


    LEVEL_9_CLEAR = False

    score = 0
    
    PC_x_pos = random.randint(400, 800)
    PC_y_pos = random.randint(300, 500)
    
    FC_x_pos = random.randint(0, 1240)
    FC_y_pos = random.randint(0, 680)

    
    Fire1_x_move = random.randint(-20, 20)
    Fire1_y_move = random.randint(-20, 20)

    Fire1_x_pos = random.randint(0, 1240)
    Fire1_y_pos = -40

    Fire2_x_move = random.randint(-20, 20)
    Fire2_y_move = random.randint(-20, 20)

    Fire2_x_pos = random.randint(0, 1240)
    Fire2_y_pos = -40

    Fire3_x_move = random.randint(-20, 20)
    Fire3_y_move = random.randint(-20, 20)

    Fire3_x_pos = random.randint(0, 1240)
    Fire3_y_pos = -40

    Fire4_x_move = random.randint(-20, 20)
    Fire4_y_move = random.randint(-20, 20)

    Fire4_x_pos = random.randint(0, 1240)
    Fire4_y_pos = -40

    Fire5_x_move = random.randint(-20, 20)
    Fire5_y_move = random.randint(-20, 20)

    Fire5_x_pos = random.randint(0, 1240)
    Fire5_y_pos = -40

    Fire6_x_move = random.randint(-20, 20)
    Fire6_y_move = random.randint(-20, 20)

    Fire6_x_pos = random.randint(0, 1240)
    Fire6_y_pos = -40

    Fire7_x_move = random.randint(-20, 20)
    Fire7_y_move = random.randint(-20, 20)

    Fire7_x_pos = -40
    Fire7_y_pos = random.randint(0, 680)

    Fire8_x_move = random.randint(-20, 20)
    Fire8_y_move = random.randint(-20, 20)

    Fire8_x_pos = -40
    Fire8_y_pos = random.randint(0, 680)

    Fire9_x_move = random.randint(-20, 20)
    Fire9_y_move = random.randint(-20, 20)

    Fire9_x_pos = -40
    Fire9_y_pos = random.randint(0, 680)

    Fire10_x_move = random.randint(-20, 20)
    Fire10_y_move = random.randint(-20, 20)

    Fire10_x_pos = -40
    Fire10_y_pos = random.randint(0, 680)

    Fire11_x_move = random.randint(-20, 20)
    Fire11_y_move = random.randint(-20, 20)

    Fire11_x_pos = -40
    Fire11_y_pos = random.randint(0, 680)

    Fire12_x_move = random.randint(-20, 20)
    Fire12_y_move = random.randint(-20, 20)

    Fire12_x_pos = -40
    Fire12_y_pos = random.randint(0, 680)

    Fires1_x_move = random.randint(-20, 20)
    Fires1_y_move = random.randint(-20, 20)

    Fires1_x_pos = random.randint(0, 1240)
    Fires1_y_pos = -40

    Fires2_x_move = random.randint(-20, 20)
    Fires2_y_move = random.randint(-20, 20)

    Fires2_x_pos = random.randint(0, 1240)
    Fires2_y_pos = -40

    Fires3_x_move = random.randint(-20, 20)
    Fires3_y_move = random.randint(-20, 20)

    Fires3_x_pos = random.randint(0, 1240)
    Fires3_y_pos = -40

    Fires4_x_move = random.randint(-20, 20)
    Fires4_y_move = random.randint(-20, 20)

    Fires4_x_pos = random.randint(0, 1240)
    Fires4_y_pos = -40

    Fires5_x_move = random.randint(-20, 20)
    Fires5_y_move = random.randint(-20, 20)

    Fires5_x_pos = random.randint(0, 1240)
    Fires5_y_pos = -40

    Fires6_x_move = random.randint(-20, 20)
    Fires6_y_move = random.randint(-20, 20)

    Fires6_x_pos = random.randint(0, 1240)
    Fires6_y_pos = -40

    Fires7_x_move = random.randint(-20, 20)
    Fires7_y_move = random.randint(-20, 20)

    Fires7_x_pos = -40
    Fires7_y_pos = random.randint(0, 680)

    Fires8_x_move = random.randint(-20, 20)
    Fires8_y_move = random.randint(-20, 20)

    Fires8_x_pos = -40
    Fires8_y_pos = random.randint(0, 680)

    Fires9_x_move = random.randint(-20, 20)
    Fires9_y_move = random.randint(-20, 20)

    Fires9_x_pos = -40
    Fires9_y_pos = random.randint(0, 680)

    Fires10_x_move = random.randint(-20, 20)
    Fires10_y_move = random.randint(-20, 20)

    Fires10_x_pos = -40
    Fires10_y_pos = random.randint(0, 680)

    Fires11_x_move = random.randint(-20, 20)
    Fires11_y_move = random.randint(-20, 20)

    Fires11_x_pos = -40
    Fires11_y_pos = random.randint(0, 680)

    Fires12_x_move = random.randint(-20, 20)
    Fires12_y_move = random.randint(-20, 20)

    Fires12_x_pos = -40
    Fires12_y_pos = random.randint(0, 680)
    

    PAUSE = False

    ALIVE = True

    while True:
        


        # 버튼 정의

        LEVEL_9_MOUSE_POS = pygame.mouse.get_pos()
        CLEAR_MOUSE_POS = pygame.mouse.get_pos()
        
        SCREEN.blit(BG, (0, 0))

        if ALIVE == True:
            SCREEN.blit(PC, (PC_x_pos, PC_y_pos))
        SCREEN.blit(FC, (FC_x_pos, FC_y_pos))

        
        SCREEN.blit(Fire, (Fire1_x_pos, Fire1_y_pos))
        SCREEN.blit(Fire, (Fire2_x_pos, Fire2_y_pos))
        SCREEN.blit(Fire, (Fire3_x_pos, Fire3_y_pos))
        SCREEN.blit(Fire, (Fire4_x_pos, Fire4_y_pos))
        SCREEN.blit(Fire, (Fire5_x_pos, Fire5_y_pos))
        SCREEN.blit(Fire, (Fire6_x_pos, Fire6_y_pos))
        SCREEN.blit(Fire, (Fire7_x_pos, Fire7_y_pos))
        SCREEN.blit(Fire, (Fire8_x_pos, Fire8_y_pos))
        SCREEN.blit(Fire, (Fire9_x_pos, Fire9_y_pos))
        SCREEN.blit(Fire, (Fire10_x_pos, Fire10_y_pos))
        SCREEN.blit(Fire, (Fire11_x_pos, Fire11_y_pos))
        SCREEN.blit(Fire, (Fire12_x_pos, Fire12_y_pos))
        SCREEN.blit(Fire, (Fires1_x_pos, Fires1_y_pos))
        SCREEN.blit(Fire, (Fires2_x_pos, Fires2_y_pos))
        SCREEN.blit(Fire, (Fires3_x_pos, Fires3_y_pos))
        SCREEN.blit(Fire, (Fires4_x_pos, Fires4_y_pos))
        SCREEN.blit(Fire, (Fires5_x_pos, Fires5_y_pos))
        SCREEN.blit(Fire, (Fires6_x_pos, Fires6_y_pos))
        SCREEN.blit(Fire, (Fires7_x_pos, Fires7_y_pos))
        SCREEN.blit(Fire, (Fires8_x_pos, Fires8_y_pos))
        SCREEN.blit(Fire, (Fires9_x_pos, Fires9_y_pos))
        SCREEN.blit(Fire, (Fires10_x_pos, Fires10_y_pos))
        SCREEN.blit(Fire, (Fires11_x_pos, Fires11_y_pos))
        SCREEN.blit(Fire, (Fires12_x_pos, Fires12_y_pos))



        LEVEL9_TEXT1 = get_font(20).render("Python = You", True, "White")
        LEVEL9_RECT1 = LEVEL9_TEXT1.get_rect(center=(160, 20))
        SCREEN.blit(LEVEL9_TEXT1, LEVEL9_RECT1)

        LEVEL9_TEXT3 = get_font(20).render("Flag = Score", True, "White")
        LEVEL9_RECT3 = LEVEL9_TEXT3.get_rect(center=(150, 50))
        SCREEN.blit(LEVEL9_TEXT3, LEVEL9_RECT3) 

        LEVEL9_TEXT5 = get_font(20).render("Fire = Death", True, "White")
        LEVEL9_RECT5 = LEVEL9_TEXT5.get_rect(center=(160, 80))
        SCREEN.blit(LEVEL9_TEXT5, LEVEL9_RECT5)


        SCORE_TEXT = get_font(20).render("Score : %d"%score, True, "White")
        SCORE_RECT = SCORE_TEXT.get_rect(center=(640, 30))
        SCREEN.blit(SCORE_TEXT, SCORE_RECT)


        Fire1_x_pos += Fire1_x_move
        Fire1_y_pos += Fire1_y_move
        if Fire1_y_pos>720:
            Fire1_x_pos = random.randint(0, 1240)
            Fire1_y_pos = -40
            Fire1_x_move = random.randint(-20, 20)
            Fire1_y_move = random.randint(-20, 20)
        elif Fire1_y_pos<-40:
            Fire1_x_pos = random.randint(0,1240)
            Fire1_y_pos = 720
            Fire1_x_move = random.randint(-20, 20)
            Fire1_y_move = random.randint(-20, 20)
        elif Fire1_x_pos<0:
            Fire1_x_pos = 1280
            Fire1_y_pos = random.randint(0, 720)
            Fire1_x_move = random.randint(-20, 20)
            Fire1_y_move = random.randint(-20, 20)
        elif Fire1_x_pos>1280:
            Fire1_x_pos = -40
            Fire1_y_pos = random.randint(0, 720)
            Fire1_x_move = random.randint(-20, 20)
            Fire1_y_move = random.randint(-20, 20)

        Fire2_x_pos += Fire2_x_move
        Fire2_y_pos += Fire2_y_move
        if Fire2_y_pos>720:
            Fire2_x_pos = random.randint(0, 1240)
            Fire2_y_pos = -40
            Fire2_x_move = random.randint(-20, 20)
            Fire2_y_move = random.randint(-20, 20)
        elif Fire2_y_pos<-40:
            Fire2_x_pos = random.randint(0,1240)
            Fire2_y_pos = 720
            Fire2_x_move = random.randint(-20, 20)
            Fire2_y_move = random.randint(-20, 20)
        elif Fire2_x_pos<0:
            Fire2_x_pos = 1280
            Fire2_y_pos = random.randint(0, 720)
            Fire2_x_move = random.randint(-20, 20)
            Fire2_y_move = random.randint(-20, 20)
        elif Fire2_x_pos>1280:
            Fire2_x_pos = -40
            Fire2_y_pos = random.randint(0, 720)
            Fire2_x_move = random.randint(-20, 20)
            Fire2_y_move = random.randint(-20, 20)


        Fire3_x_pos += Fire3_x_move
        Fire3_y_pos += Fire3_y_move
        if Fire3_y_pos>720:
            Fire3_x_pos = random.randint(0, 1240)
            Fire3_y_pos = -40
            Fire3_x_move = random.randint(-20, 20)
            Fire3_y_move = random.randint(-20, 20)
        elif Fire3_y_pos<-40:
            Fire3_x_pos = random.randint(0,1240)
            Fire3_y_pos = 720
            Fire3_x_move = random.randint(-20, 20)
            Fire3_y_move = random.randint(-20, 20)
        elif Fire3_x_pos<0:
            Fire3_x_pos = 1280
            Fire3_y_pos = random.randint(0, 720)
            Fire3_x_move = random.randint(-20, 20)
            Fire3_y_move = random.randint(-20, 20)
        elif Fire3_x_pos>1280:
            Fire3_x_pos = -40
            Fire3_y_pos = random.randint(0, 720)
            Fire3_x_move = random.randint(-20, 20)
            Fire3_y_move = random.randint(-20, 20)

        Fire4_x_pos += Fire4_x_move
        Fire4_y_pos += Fire4_y_move
        if Fire4_y_pos>720:
            Fire4_x_pos = random.randint(0, 1240)
            Fire4_y_pos = -40
            Fire4_x_move = random.randint(-20, 20)
            Fire4_y_move = random.randint(-20, 20)
        elif Fire4_y_pos<-40:
            Fire4_x_pos = random.randint(0,1240)
            Fire4_y_pos = 720
            Fire4_x_move = random.randint(-20, 20)
            Fire4_y_move = random.randint(-20, 20)
        elif Fire4_x_pos<0:
            Fire4_x_pos = 1280
            Fire4_y_pos = random.randint(0, 720)
            Fire4_x_move = random.randint(-20, 20)
            Fire4_y_move = random.randint(-20, 20)
        elif Fire4_x_pos>1280:
            Fire4_x_pos = -40
            Fire4_y_pos = random.randint(0, 720)
            Fire4_x_move = random.randint(-20, 20)
            Fire4_y_move = random.randint(-20, 20)


        Fire5_x_pos += Fire5_x_move
        Fire5_y_pos += Fire5_y_move
        if Fire5_y_pos>720:
            Fire5_x_pos = random.randint(0, 1240)
            Fire5_y_pos = -40
            Fire5_x_move = random.randint(-20, 20)
            Fire5_y_move = random.randint(-20, 20)
        elif Fire5_y_pos<-40:
            Fire5_x_pos = random.randint(0,1240)
            Fire5_y_pos = 720
            Fire5_x_move = random.randint(-20, 20)
            Fire5_y_move = random.randint(-20, 20)
        elif Fire5_x_pos<0:
            Fire5_x_pos = 1280
            Fire5_y_pos = random.randint(0, 720)
            Fire5_x_move = random.randint(-20, 20)
            Fire5_y_move = random.randint(-20, 20)
        elif Fire5_x_pos>1280:
            Fire5_x_pos = -40
            Fire5_y_pos = random.randint(0, 720)
            Fire5_x_move = random.randint(-20, 20)
            Fire5_y_move = random.randint(-20, 20)

        Fire6_x_pos += Fire6_x_move
        Fire6_y_pos += Fire6_y_move
        if Fire6_y_pos>720:
            Fire6_x_pos = random.randint(0, 1240)
            Fire6_y_pos = -40
            Fire6_x_move = random.randint(-20, 20)
            Fire6_y_move = random.randint(-20, 20)
        elif Fire6_y_pos<-40:
            Fire6_x_pos = random.randint(0,1240)
            Fire6_y_pos = 720
            Fire6_x_move = random.randint(-20, 20)
            Fire6_y_move = random.randint(-20, 20)
        elif Fire6_x_pos<0:
            Fire6_x_pos = 1280
            Fire6_y_pos = random.randint(0, 720)
            Fire6_x_move = random.randint(-20, 20)
            Fire6_y_move = random.randint(-20, 20)
        elif Fire6_x_pos>1280:
            Fire6_x_pos = -40
            Fire6_y_pos = random.randint(0, 720)
            Fire6_x_move = random.randint(-20, 20)
            Fire6_y_move = random.randint(-20, 20)

        Fire7_x_pos += Fire7_x_move
        Fire7_y_pos += Fire7_y_move
        if Fire7_y_pos>720:
            Fire7_x_pos = random.randint(0, 1240)
            Fire7_y_pos = -40
            Fire7_x_move = random.randint(-20, 20)
            Fire7_y_move = random.randint(-20, 20)
        elif Fire7_y_pos<-40:
            Fire7_x_pos = random.randint(0,1240)
            Fire7_y_pos = 720
            Fire7_x_move = random.randint(-20, 20)
            Fire7_y_move = random.randint(-20, 20)
        elif Fire7_x_pos<0:
            Fire7_x_pos = 1280
            Fire7_y_pos = random.randint(0, 720)
            Fire7_x_move = random.randint(-20, 20)
            Fire7_y_move = random.randint(-20, 20)
        elif Fire7_x_pos>1280:
            Fire7_x_pos = -40
            Fire7_y_pos = random.randint(0, 720)
            Fire7_x_move = random.randint(-20, 20)
            Fire7_y_move = random.randint(-20, 20)

        Fire8_x_pos += Fire8_x_move
        Fire8_y_pos += Fire8_y_move
        if Fire8_y_pos>720:
            Fire8_x_pos = random.randint(0, 1240)
            Fire8_y_pos = -40
            Fire8_x_move = random.randint(-20, 20)
            Fire8_y_move = random.randint(-20, 20)
        elif Fire8_y_pos<-40:
            Fire8_x_pos = random.randint(0,1240)
            Fire8_y_pos = 720
            Fire8_x_move = random.randint(-20, 20)
            Fire8_y_move = random.randint(-20, 20)
        elif Fire8_x_pos<0:
            Fire8_x_pos = 1280
            Fire8_y_pos = random.randint(0, 720)
            Fire8_x_move = random.randint(-20, 20)
            Fire8_y_move = random.randint(-20, 20)
        elif Fire8_x_pos>1280:
            Fire8_x_pos = -40
            Fire8_y_pos = random.randint(0, 720)
            Fire8_x_move = random.randint(-20, 20)
            Fire8_y_move = random.randint(-20, 20)

        Fire9_x_pos += Fire9_x_move
        Fire9_y_pos += Fire9_y_move
        if Fire9_y_pos>720:
            Fire9_x_pos = random.randint(0, 1240)
            Fire9_y_pos = -40
            Fire9_x_move = random.randint(-20, 20)
            Fire9_y_move = random.randint(-20, 20)
        elif Fire9_y_pos<-40:
            Fire9_x_pos = random.randint(0,1240)
            Fire9_y_pos = 720
            Fire9_x_move = random.randint(-20, 20)
            Fire9_y_move = random.randint(-20, 20)
        elif Fire9_x_pos<0:
            Fire9_x_pos = 1280
            Fire9_y_pos = random.randint(0, 720)
            Fire9_x_move = random.randint(-20, 20)
            Fire9_y_move = random.randint(-20, 20)
        elif Fire9_x_pos>1280:
            Fire9_x_pos = -40
            Fire9_y_pos = random.randint(0, 720)
            Fire9_x_move = random.randint(-20, 20)
            Fire9_y_move = random.randint(-20, 20)


        Fire10_x_pos += Fire10_x_move
        Fire10_y_pos += Fire10_y_move
        if Fire10_y_pos>720:
            Fire10_x_pos = random.randint(0, 1240)
            Fire10_y_pos = -40
            Fire10_x_move = random.randint(-20, 20)
            Fire10_y_move = random.randint(-20, 20)
        elif Fire10_y_pos<-40:
            Fire10_x_pos = random.randint(0,1240)
            Fire10_y_pos = 720
            Fire10_x_move = random.randint(-20, 20)
            Fire10_y_move = random.randint(-20, 20)
        elif Fire10_x_pos<0:
            Fire10_x_pos = 1280
            Fire10_y_pos = random.randint(0, 720)
            Fire10_x_move = random.randint(-20, 20)
            Fire10_y_move = random.randint(-20, 20)
        elif Fire10_x_pos>1280:
            Fire10_x_pos = -40
            Fire10_y_pos = random.randint(0, 720)
            Fire10_x_move = random.randint(-20, 20)
            Fire10_y_move = random.randint(-20, 20)

        Fire11_x_pos += Fire11_x_move
        Fire11_y_pos += Fire11_y_move
        if Fire11_y_pos>720:
            Fire11_x_pos = random.randint(0, 1240)
            Fire11_y_pos = -40
            Fire11_x_move = random.randint(-20, 20)
            Fire11_y_move = random.randint(-20, 20)
        elif Fire11_y_pos<-40:
            Fire11_x_pos = random.randint(0,1240)
            Fire11_y_pos = 720
            Fire11_x_move = random.randint(-20, 20)
            Fire11_y_move = random.randint(-20, 20)
        elif Fire11_x_pos<0:
            Fire11_x_pos = 1280
            Fire11_y_pos = random.randint(0, 720)
            Fire11_x_move = random.randint(-20, 20)
            Fire11_y_move = random.randint(-20, 20)
        elif Fire11_x_pos>1280:
            Fire11_x_pos = -40
            Fire11_y_pos = random.randint(0, 720)
            Fire11_x_move = random.randint(-20, 20)
            Fire11_y_move = random.randint(-20, 20)

        Fire12_x_pos += Fire12_x_move
        Fire12_y_pos += Fire12_y_move
        if Fire12_y_pos>720:
            Fire12_x_pos = random.randint(0, 1240)
            Fire12_y_pos = -40
            Fire12_x_move = random.randint(-20, 20)
            Fire12_y_move = random.randint(-20, 20)
        elif Fire12_y_pos<-40:
            Fire12_x_pos = random.randint(0,1240)
            Fire12_y_pos = 720
            Fire12_x_move = random.randint(-20, 20)
            Fire12_y_move = random.randint(-20, 20)
        elif Fire12_x_pos<0:
            Fire12_x_pos = 1280
            Fire12_y_pos = random.randint(0, 720)
            Fire12_x_move = random.randint(-20, 20)
            Fire12_y_move = random.randint(-20, 20)
        elif Fire12_x_pos>1280:
            Fire12_x_pos = -40
            Fire12_y_pos = random.randint(0, 720)
            Fire12_x_move = random.randint(-20, 20)
            Fire12_y_move = random.randint(-20, 20)


        if score >= 20:
            
            Fires1_x_pos += Fires1_x_move
            Fires1_y_pos += Fires1_y_move
            if Fires1_y_pos>720:
                Fires1_x_pos = random.randint(0, 1240)
                Fires1_y_pos = -40
                Fires1_x_move = random.randint(-20, 20)
                Fires1_y_move = random.randint(-20, 20)
            elif Fires1_y_pos<-40:
                Fires1_x_pos = random.randint(0,1240)
                Fires1_y_pos = 720
                Fires1_x_move = random.randint(-20, 20)
                Fires1_y_move = random.randint(-20, 20)
            elif Fires1_x_pos<0:
                Fires1_x_pos = 1280
                Fires1_y_pos = random.randint(0, 720)
                Fires1_x_move = random.randint(-20, 20)
                Fires1_y_move = random.randint(-20, 20)
            elif Fires1_x_pos>1280:
                Fires1_x_pos = -40
                Fires1_y_pos = random.randint(0, 720)
                Fires1_x_move = random.randint(-20, 20)
                Fires1_y_move = random.randint(-20, 20)

            Fires2_x_pos += Fires2_x_move
            Fires2_y_pos += Fires2_y_move
            if Fires2_y_pos>720:
                Fires2_x_pos = random.randint(0, 1240)
                Fires2_y_pos = -40
                Fires2_x_move = random.randint(-20, 20)
                Fires2_y_move = random.randint(-20, 20)
            elif Fires2_y_pos<-40:
                Fires2_x_pos = random.randint(0,1240)
                Fires2_y_pos = 720
                Fires2_x_move = random.randint(-20, 20)
                Fires2_y_move = random.randint(-20, 20)
            elif Fires2_x_pos<0:
                Fires2_x_pos = 1280
                Fires2_y_pos = random.randint(0, 720)
                Fires2_x_move = random.randint(-20, 20)
                Fires2_y_move = random.randint(-20, 20)
            elif Fires2_x_pos>1280:
                Fires2_x_pos = -40
                Fires2_y_pos = random.randint(0, 720)
                Fires2_x_move = random.randint(-20, 20)
                Fires2_y_move = random.randint(-20, 20)


            Fires3_x_pos += Fires3_x_move
            Fires3_y_pos += Fires3_y_move
            if Fires3_y_pos>720:
                Fires3_x_pos = random.randint(0, 1240)
                Fires3_y_pos = -40
                Fires3_x_move = random.randint(-20, 20)
                Fires3_y_move = random.randint(-20, 20)
            elif Fires3_y_pos<-40:
                Fires3_x_pos = random.randint(0,1240)
                Fires3_y_pos = 720
                Fires3_x_move = random.randint(-20, 20)
                Fires3_y_move = random.randint(-20, 20)
            elif Fires3_x_pos<0:
                Fires3_x_pos = 1280
                Fires3_y_pos = random.randint(0, 720)
                Fires3_x_move = random.randint(-20, 20)
                Fires3_y_move = random.randint(-20, 20)
            elif Fires3_x_pos>1280:
                Fires3_x_pos = -40
                Fires3_y_pos = random.randint(0, 720)
                Fires3_x_move = random.randint(-20, 20)
                Fires3_y_move = random.randint(-20, 20)

            Fires4_x_pos += Fires4_x_move
            Fires4_y_pos += Fires4_y_move
            if Fires4_y_pos>720:
                Fires4_x_pos = random.randint(0, 1240)
                Fires4_y_pos = -40
                Fires4_x_move = random.randint(-20, 20)
                Fires4_y_move = random.randint(-20, 20)
            elif Fires4_y_pos<-40:
                Fires4_x_pos = random.randint(0,1240)
                Fires4_y_pos = 720
                Fires4_x_move = random.randint(-20, 20)
                Fires4_y_move = random.randint(-20, 20)
            elif Fires4_x_pos<0:
                Fires4_x_pos = 1280
                Fires4_y_pos = random.randint(0, 720)
                Fires4_x_move = random.randint(-20, 20)
                Fires4_y_move = random.randint(-20, 20)
            elif Fires4_x_pos>1280:
                Fires4_x_pos = -40
                Fires4_y_pos = random.randint(0, 720)
                Fires4_x_move = random.randint(-20, 20)
                Fires4_y_move = random.randint(-20, 20)


        if score >= 100:
            Fires5_x_pos += Fires5_x_move
            Fires5_y_pos += Fires5_y_move
            if Fires5_y_pos>720:
                Fires5_x_pos = random.randint(0, 1240)
                Fires5_y_pos = -40
                Fires5_x_move = random.randint(-20, 20)
                Fires5_y_move = random.randint(-20, 20)
            elif Fires5_y_pos<-40:
                Fires5_x_pos = random.randint(0,1240)
                Fires5_y_pos = 720
                Fires5_x_move = random.randint(-20, 20)
                Fires5_y_move = random.randint(-20, 20)
            elif Fires5_x_pos<0:
                Fires5_x_pos = 1280
                Fires5_y_pos = random.randint(0, 720)
                Fires5_x_move = random.randint(-20, 20)
                Fires5_y_move = random.randint(-20, 20)
            elif Fires5_x_pos>1280:
                Fires5_x_pos = -40
                Fires5_y_pos = random.randint(0, 720)
                Fires5_x_move = random.randint(-20, 20)
                Fires5_y_move = random.randint(-20, 20)

            Fires6_x_pos += Fires6_x_move
            Fires6_y_pos += Fires6_y_move
            if Fires6_y_pos>720:
                Fires6_x_pos = random.randint(0, 1240)
                Fires6_y_pos = -40
                Fires6_x_move = random.randint(-20, 20)
                Fires6_y_move = random.randint(-20, 20)
            elif Fires6_y_pos<-40:
                Fires6_x_pos = random.randint(0,1240)
                Fires6_y_pos = 720
                Fires6_x_move = random.randint(-20, 20)
                Fires6_y_move = random.randint(-20, 20)
            elif Fires6_x_pos<0:
                Fires6_x_pos = 1280
                Fires6_y_pos = random.randint(0, 720)
                Fires6_x_move = random.randint(-20, 20)
                Fires6_y_move = random.randint(-20, 20)
            elif Fires6_x_pos>1280:
                Fires6_x_pos = -40
                Fires6_y_pos = random.randint(0, 720)
                Fires6_x_move = random.randint(-20, 20)
                Fires6_y_move = random.randint(-20, 20)

            Fires7_x_pos += Fires7_x_move
            Fires7_y_pos += Fires7_y_move
            if Fires7_y_pos>720:
                Fires7_x_pos = random.randint(0, 1240)
                Fires7_y_pos = -40
                Fires7_x_move = random.randint(-20, 20)
                Fires7_y_move = random.randint(-20, 20)
            elif Fires7_y_pos<-40:
                Fires7_x_pos = random.randint(0,1240)
                Fires7_y_pos = 720
                Fires7_x_move = random.randint(-20, 20)
                Fires7_y_move = random.randint(-20, 20)
            elif Fires7_x_pos<0:
                Fires7_x_pos = 1280
                Fires7_y_pos = random.randint(0, 720)
                Fires7_x_move = random.randint(-20, 20)
                Fires7_y_move = random.randint(-20, 20)
            elif Fires7_x_pos>1280:
                Fires7_x_pos = -40
                Fires7_y_pos = random.randint(0, 720)
                Fires7_x_move = random.randint(-20, 20)
                Fires7_y_move = random.randint(-20, 20)

        if score >= 200:

            Fires8_x_pos += Fires8_x_move
            Fires8_y_pos += Fires8_y_move
            if Fires8_y_pos>720:
                Fires8_x_pos = random.randint(0, 1240)
                Fires8_y_pos = -40
                Fires8_x_move = random.randint(-20, 20)
                Fires8_y_move = random.randint(-20, 20)
            elif Fires8_y_pos<-40:
                Fires8_x_pos = random.randint(0,1240)
                Fires8_y_pos = 720
                Fires8_x_move = random.randint(-20, 20)
                Fires8_y_move = random.randint(-20, 20)
            elif Fires8_x_pos<0:
                Fires8_x_pos = 1280
                Fires8_y_pos = random.randint(0, 720)
                Fires8_x_move = random.randint(-20, 20)
                Fires8_y_move = random.randint(-20, 20)
            elif Fires8_x_pos>1280:
                Fires8_x_pos = -40
                Fires8_y_pos = random.randint(0, 720)
                Fires8_x_move = random.randint(-20, 20)
                Fires8_y_move = random.randint(-20, 20)

            Fires9_x_pos += Fires9_x_move
            Fires9_y_pos += Fires9_y_move
            if Fires9_y_pos>720:
                Fires9_x_pos = random.randint(0, 1240)
                Fires9_y_pos = -40
                Fires9_x_move = random.randint(-20, 20)
                Fires9_y_move = random.randint(-20, 20)
            elif Fires9_y_pos<-40:
                Fires9_x_pos = random.randint(0,1240)
                Fires9_y_pos = 720
                Fires9_x_move = random.randint(-20, 20)
                Fires9_y_move = random.randint(-20, 20)
            elif Fires9_x_pos<0:
                Fires9_x_pos = 1280
                Fires9_y_pos = random.randint(0, 720)
                Fires9_x_move = random.randint(-20, 20)
                Fires9_y_move = random.randint(-20, 20)
            elif Fires9_x_pos>1280:
                Fires9_x_pos = -40
                Fires9_y_pos = random.randint(0, 720)
                Fires9_x_move = random.randint(-20, 20)
                Fires9_y_move = random.randint(-20, 20)


            Fires10_x_pos += Fires10_x_move
            Fires10_y_pos += Fires10_y_move
            if Fires10_y_pos>720:
                Fires10_x_pos = random.randint(0, 1240)
                Fires10_y_pos = -40
                Fires10_x_move = random.randint(-20, 20)
                Fires10_y_move = random.randint(-20, 20)
            elif Fires10_y_pos<-40:
                Fires10_x_pos = random.randint(0,1240)
                Fires10_y_pos = 720
                Fires10_x_move = random.randint(-20, 20)
                Fires10_y_move = random.randint(-20, 20)
            elif Fires10_x_pos<0:
                Fires10_x_pos = 1280
                Fires10_y_pos = random.randint(0, 720)
                Fires10_x_move = random.randint(-20, 20)
                Fires10_y_move = random.randint(-20, 20)
            elif Fires10_x_pos>1280:
                Fires10_x_pos = -40
                Fires10_y_pos = random.randint(0, 720)
                Fires10_x_move = random.randint(-20, 20)
                Fires10_y_move = random.randint(-20, 20)

            Fires11_x_pos += Fires11_x_move
            Fires11_y_pos += Fires11_y_move
            if Fires11_y_pos>720:
                Fires11_x_pos = random.randint(0, 1240)
                Fires11_y_pos = -40
                Fires11_x_move = random.randint(-20, 20)
                Fires11_y_move = random.randint(-20, 20)
            elif Fires11_y_pos<-40:
                Fires11_x_pos = random.randint(0,1240)
                Fires11_y_pos = 720
                Fires11_x_move = random.randint(-20, 20)
                Fires11_y_move = random.randint(-20, 20)
            elif Fires11_x_pos<0:
                Fires11_x_pos = 1280
                Fires11_y_pos = random.randint(0, 720)
                Fires11_x_move = random.randint(-20, 20)
                Fires11_y_move = random.randint(-20, 20)
            elif Fires11_x_pos>1280:
                Fires11_x_pos = -40
                Fires11_y_pos = random.randint(0, 720)
                Fires11_x_move = random.randint(-20, 20)
                Fires11_y_move = random.randint(-20, 20)

            Fires12_x_pos += Fires12_x_move
            Fires12_y_pos += Fires12_y_move
            if Fires12_y_pos>720:
                Fires12_x_pos = random.randint(0, 1240)
                Fires12_y_pos = -40
                Fires12_x_move = random.randint(-20, 20)
                Fires12_y_move = random.randint(-20, 20)
            elif Fires12_y_pos<-40:
                Fires12_x_pos = random.randint(0,1240)
                Fires12_y_pos = 720
                Fires12_x_move = random.randint(-20, 20)
                Fires12_y_move = random.randint(-20, 20)
            elif Fires12_x_pos<0:
                Fires12_x_pos = 1280
                Fires12_y_pos = random.randint(0, 720)
                Fires12_x_move = random.randint(-20, 20)
                Fires12_y_move = random.randint(-20, 20)
            elif Fires12_x_pos>1280:
                Fires12_x_pos = -40
                Fires12_y_pos = random.randint(0, 720)
                Fires12_x_move = random.randint(-20, 20)
                Fires12_y_move = random.randint(-20, 20)
            



        Fx = [Fire1_x_pos, Fire2_x_pos, Fire3_x_pos, Fire4_x_pos, Fire5_x_pos, Fire6_x_pos, Fire7_x_pos, Fire8_x_pos, Fire9_x_pos, Fire10_x_pos, Fire11_x_pos, Fire12_x_pos, Fires1_x_pos, Fires2_x_pos, Fires3_x_pos, Fires4_x_pos, Fires5_x_pos, Fires6_x_pos, Fires7_x_pos, Fires8_x_pos, Fires9_x_pos, Fires10_x_pos, Fires11_x_pos, Fires12_x_pos]
        Fy = [Fire1_y_pos, Fire2_y_pos, Fire3_y_pos, Fire4_y_pos, Fire5_y_pos, Fire6_y_pos, Fire7_y_pos, Fire8_y_pos, Fire9_y_pos, Fire10_y_pos, Fire11_y_pos, Fire12_y_pos, Fires1_y_pos, Fires2_y_pos, Fires3_y_pos, Fires4_y_pos, Fires5_y_pos, Fires6_y_pos, Fires7_y_pos, Fires8_y_pos, Fires9_y_pos, Fires10_y_pos, Fires11_y_pos, Fires12_y_pos]
        for i in Fx:
            for j in Fy:
                if Fx.index(i) == Fy.index(j) and (-30<i-PC_x_pos<30 and -30<j-PC_y_pos<30):
                    ALIVE = False

        if (-40<FC_x_pos-PC_x_pos<40 and -40<FC_y_pos-PC_y_pos<40) and ALIVE == True:
            score += 10
            FC_x_pos = random.randint(0, 1240)
            FC_y_pos = random.randint(0, 680)
            
        if ALIVE == False:
            SCREEN.blit(BG, (0, 0))
            GAME_OVER_TEXT = get_font(45).render("Score: %d"%score, True, "White")
            GAME_OVER_RECT = GAME_OVER_TEXT.get_rect(center=(640, 200))
            SCREEN.blit(GAME_OVER_TEXT, GAME_OVER_RECT)
            RESTART = Button(image=None, pos=(640,420), text_input="Restart", font=get_font(30), \
                             base_color="White", hovering_color="Green")
            RESTART.changeColor(CLEAR_MOUSE_POS)
            RESTART.update(SCREEN)
            BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30), \
                                base_color="White", hovering_color="Green")
            BACKTOMENU.changeColor(CLEAR_MOUSE_POS)
            BACKTOMENU.update(SCREEN)
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    pygame.quit()
                    sys.exit()
                if event.type == pygame.MOUSEBUTTONDOWN:
                    if BACKTOMENU.checkForInput(CLEAR_MOUSE_POS):
                        play()
                    if RESTART.checkForInput(CLEAR_MOUSE_POS):
                        level_10()
                        
        

                        
            pygame.display.update()

# 파이썬 캐릭터 움직임
            
        for event in pygame.event.get():
                
            if event.type == pygame.KEYDOWN:
                    
                if event.key == pygame.K_a and PC_x_pos>0  and ALIVE == True:
                    PC_x_pos -= 40
          
                if event.key == pygame.K_d and PC_x_pos<1240  and ALIVE == True:
                    PC_x_pos += 40
      
                if event.key == pygame.K_w and PC_y_pos>0  and ALIVE == True:
                    PC_y_pos -= 40            
                        
                if event.key == pygame.K_s and PC_y_pos<680  and ALIVE == True:
                    PC_y_pos += 40


                if event.key == pygame.K_r:
                    level_9()

                if event.key == pygame.K_ESCAPE:
                    PAUSE = True

            while PAUSE == True:
                PAUSE_MOUSE_POS = pygame.mouse.get_pos()
                
                SCREEN.blit(BG, (0, 0))
                PAUSE_TEXT = get_font(45).render("paused", True, "White")
                PAUSE_RECT = PAUSE_TEXT.get_rect(center=(640, 200))
                SCREEN.blit(PAUSE_TEXT, PAUSE_RECT)
                BACKTOMENU = Button(image=None, pos=(640,480), text_input="back to menu", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOMENU.changeColor(PAUSE_MOUSE_POS)
                BACKTOMENU.update(SCREEN)
                BACKTOGAME = Button(image=None, pos=(640,420), text_input="back to game", font=get_font(30),
                                base_color="White", hovering_color="Green")
                BACKTOGAME.changeColor(PAUSE_MOUSE_POS)
                BACKTOGAME.update(SCREEN)

                pygame.display.update()

                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    if event.type == pygame.MOUSEBUTTONDOWN:
                        if BACKTOMENU.checkForInput(PAUSE_MOUSE_POS):
                            play()
                        if BACKTOGAME.checkForInput(PAUSE_MOUSE_POS):
                            PAUSE = False
                    

                        
            pygame.display.update()
                
        pygame.display.update()




        
main_menu()
